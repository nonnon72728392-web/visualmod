package com.visualmod;

/** Интерфейс, который через миксин добавляется в ItemEntityRenderState. */
public interface ItemStateExt {
    boolean visualmod$isOnGround();

    void visualmod$setOnGround(boolean onGround);
}
