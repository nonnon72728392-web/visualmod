package com.visualmod;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Все настройки мода. Сохраняются в config/visualmod.properties.
 * Любое новое public static поле (boolean / int / float) сохраняется и грузится автоматически.
 */
public final class Config {
    private Config() {}

    // ---------------------------------------------------------------- Visuals
    public static boolean esp = false;
    public static int espMode = 0;            // 0 = Box, 1 = Glow
    public static int espColor = 0;           // 0 Accent, 1 Rainbow, 2 White
    public static boolean espMobs = false;
    public static boolean espFill = true;
    public static boolean espHealth = true;

    public static boolean seeInvisibles = false;
    public static boolean siPlayersOnly = false;

    public static boolean fullbright = false;

    public static boolean nameTags = false;
    public static float ntScale = 1.0f;
    public static float ntBg = 0.69f;
    public static boolean ntDistance = true;
    public static boolean ntHealth = true;
    public static boolean ntPotions = true;   // эффекты зелий над ником

    public static boolean itemPhysics = false;
    public static float ipSpin = 1.0f;

    // ---------------------------------------------------------------- World
    public static boolean jumpCircle = false;
    public static int jcColor = 0;            // 0 Accent, 1 Rainbow, 2 White
    public static float jcRadius = 1.6f;
    public static float jcDuration = 1.0f;    // секунды
    public static boolean jcOthers = false;

    public static boolean chinaHat = false;
    public static int chColor = 0;
    public static float chRadius = 0.55f;
    public static float chHeight = 0.42f;
    public static float chAlpha = 0.6f;
    public static boolean chOthers = false;

    public static boolean noParticles = false;
    public static boolean npKeepTotem = false;
    public static boolean npKeepHit = false;

    public static boolean noHurtCam = false;
    public static boolean noBob = false;

    public static boolean noFire = false;

    public static boolean zoom = false;
    public static int zoomBind = 67;          // C
    public static float zoomLevel = 4.0f;
    public static boolean zoomSmooth = true;

    public static final String[] COLOR_MODES = {"Accent", "Rainbow", "White"};

    // ---------------------------------------------------------------- Hands
    public static boolean viewModel = false;
    public static float vmX = 0.0f;
    public static float vmY = 0.0f;
    public static float vmZ = 0.0f;
    public static float vmScale = 1.0f;

    public static boolean swingAnim = false;
    public static float swingSpeed = 6.0f;
    public static float swingAngle = 0.0f;
    public static int swingStyle = 1;
    public static final String[] SWING_STYLES = {"Vanilla", "Sideways", "Push"};

    // ---------------------------------------------------------------- Combat
    public static boolean hitInfo = false;
    public static float hiHold = 10.0f;       // сколько секунд держим цель после последнего удара
    public static boolean hiName = true;
    public static boolean hiBar = true;
    public static boolean hiHealed = true;
    public static boolean hiLast = true;

    public static boolean triggerBot = false;
    public static float tbCharge = 0.9f;      // минимальная зарядка удара (1.0 = полная)
    public static float tbDelay = 0.0f;       // доп. задержка в тиках перед ударом
    public static boolean tbPlayersOnly = true;

    public static boolean autoTotem = false;
    public static float atDelay = 2.0f;       // тиков между попытками
    public static float atHealth = 0.0f;      // 0 = всегда держать тотем в левой руке
    public static boolean atEmptyOnly = false;

    public static boolean clickPearl = false;
    public static int cpBind = -102;          // -100 - кнопка мыши (СКМ), >= 0 клавиша GLFW, -1 = нет
    public static boolean cpSwing = true;

    public static boolean clickWind = false;
    public static int cwBind = -1;
    public static boolean cwAimDown = true;
    public static boolean cwSwing = true;

    // ---------------------------------------------------------------- Misc
    public static boolean autoSprint = false;
    public static boolean autoRespawn = false;
    public static float arDelay = 0.0f;       // тиков до респавна

    // ---------------------------------------------------------------- HUD
    public static boolean hud = true;
    public static boolean hudWatermark = true;
    public static boolean hudFps = true;
    public static boolean hudPing = true;
    public static boolean hudModuleList = true;
    public static boolean mlDots = true;
    public static boolean hudInfo = true;
    public static boolean hudFacing = true;
    public static boolean hudKeys = true;
    public static boolean ksSpace = true;
    public static boolean hudArmor = false;
    public static boolean haVertical = false;
    public static boolean haDurability = true;
    public static boolean hudPotions = false;
    public static boolean hpTimer = true;
    public static boolean hudCounts = false;
    public static boolean ctTotem = true;
    public static boolean ctPearl = true;
    public static boolean ctWind = true;
    public static int font = 3;   // 0 Vanilla, 1 JetBrains Mono, 2 Geist Mono, 3 Carlito (сглаженный TTF)
    public static final String[] FONT_NAMES = {"Vanilla", "JetBrains", "Geist", "Carlito"};
    public static boolean uiAnim = true;

    public static final int HUD_ELEMS = 8;
    /** 0 watermark, 1 info, 2 module list (x = ПРАВЫЙ край, -1 = по умолчанию), 3 keystrokes, 4 hit info, 5 armor, 6 counters, 7 potions. */
    public static int[] hudX = {4, 4, -1, 4, 4, 4, 4, 4};
    public static int[] hudY = {4, 23, 4, 44, 104, 170, 146, 200};

    // ---------------------------------------------------------------- Тема
    public static int accent = 0;
    public static final int[] ACCENTS = {0xFF7C4DFF, 0xFF00BCD4, 0xFFFF5252, 0xFF69F0AE, 0xFFFFB300};
    public static final String[] ACCENT_NAMES = {"Violet", "Cyan", "Red", "Green", "Amber"};

    public static int accent() {
        return ACCENTS[Math.floorMod(accent, ACCENTS.length)];
    }

    public static String accentName() {
        return ACCENT_NAMES[Math.floorMod(accent, ACCENT_NAMES.length)];
    }

    public static void resetHud() {
        hudX = new int[]{4, 4, -1, 4, 4, 4, 4, 4};
        hudY = new int[]{4, 23, 4, 44, 104, 170, 146, 200};
    }

    public static void resetViewModel() {
        vmX = 0.0f;
        vmY = 0.0f;
        vmZ = 0.0f;
        vmScale = 1.0f;
    }

    // ---------------------------------------------------------------- клавиши включения модулей

    /** id модуля -> клавиша/кнопка мыши (-1 = нет). Сохраняется как bind.<id>. */
    public static final Map<String, Integer> BINDS = new HashMap<>();

    public static int bind(String id) {
        return BINDS.getOrDefault(id, -1);
    }

    public static void setBind(String id, int code) {
        if (code == -1) BINDS.remove(id);
        else BINDS.put(id, code);
    }

    // ---------------------------------------------------------------- сохранение

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("visualmod.properties");
    }

    private static boolean persisted(Field f) {
        int m = f.getModifiers();
        if (!Modifier.isStatic(m) || Modifier.isFinal(m)) return false;
        Class<?> t = f.getType();
        return t == boolean.class || t == int.class || t == float.class;
    }

    public static void save() {
        Properties p = new Properties();
        try {
            for (Field f : Config.class.getDeclaredFields()) {
                if (persisted(f)) p.setProperty(f.getName(), String.valueOf(f.get(null)));
            }
        } catch (IllegalAccessException ignored) {
        }
        for (int i = 0; i < HUD_ELEMS; i++) {
            p.setProperty("hudX" + i, String.valueOf(hudX[i]));
            p.setProperty("hudY" + i, String.valueOf(hudY[i]));
        }
        for (Map.Entry<String, Integer> e : BINDS.entrySet()) {
            p.setProperty("bind." + e.getKey(), String.valueOf(e.getValue()));
        }
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "VisualMod");
        } catch (IOException ignored) {
        }
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        // старые конфиги хранили шрифт под ключом fontId
        if (p.getProperty("font") == null && p.getProperty("fontId") != null) {
            p.setProperty("font", p.getProperty("fontId"));
        }
        for (Field fld : Config.class.getDeclaredFields()) {
            if (!persisted(fld)) continue;
            String v = p.getProperty(fld.getName());
            if (v == null) continue;
            try {
                Class<?> t = fld.getType();
                if (t == boolean.class) fld.setBoolean(null, Boolean.parseBoolean(v));
                else if (t == int.class) fld.setInt(null, (int) Float.parseFloat(v));
                else fld.setFloat(null, Float.parseFloat(v));
            } catch (Exception ignored) {
            }
        }
        for (int i = 0; i < HUD_ELEMS; i++) {
            hudX[i] = (int) num(p, "hudX" + i, hudX[i]);
            hudY[i] = (int) num(p, "hudY" + i, hudY[i]);
        }
        BINDS.clear();
        for (String key : p.stringPropertyNames()) {
            if (!key.startsWith("bind.")) continue;
            try {
                BINDS.put(key.substring(5), Integer.parseInt(p.getProperty(key).trim()));
            } catch (NumberFormatException ignored) {
            }
        }
        espMode = Math.floorMod(espMode, 2);
        espColor = Math.floorMod(espColor, COLOR_MODES.length);
        swingStyle = Math.floorMod(swingStyle, SWING_STYLES.length);
        font = Math.floorMod(font, FONT_NAMES.length);
        jcColor = Math.floorMod(jcColor, COLOR_MODES.length);
        chColor = Math.floorMod(chColor, COLOR_MODES.length);
    }

    private static float num(Properties p, String key, float def) {
        String v = p.getProperty(key);
        if (v == null) return def;
        try {
            return Float.parseFloat(v);
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
