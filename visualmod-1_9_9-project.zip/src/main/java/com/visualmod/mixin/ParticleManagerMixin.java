package com.visualmod.mixin;

import com.visualmod.Config;
import com.visualmod.ParticleFilter;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * No Particles: частицы не создаются вообще - нет ни спавна, ни тика, ни рендера (прирост FPS).
 * В настройках можно оставить тотем и/или частицы ударов.
 */
@Mixin(ParticleManager.class)
public abstract class ParticleManagerMixin {
    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void visualmod$noEffect(ParticleEffect parameters, double x, double y, double z,
                                    double velocityX, double velocityY, double velocityZ,
                                    CallbackInfoReturnable<Particle> cir) {
        if (Config.noParticles && !ParticleFilter.keep(parameters)) cir.setReturnValue(null);
    }

    @Inject(method = "addParticle(Lnet/minecraft/client/particle/Particle;)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void visualmod$noParticle(Particle particle, CallbackInfo ci) {
        if (Config.noParticles && !ParticleFilter.anyKept()) ci.cancel();
    }

    @Inject(method = "addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void visualmod$noEmitter(Entity entity, ParticleEffect parameters, CallbackInfo ci) {
        if (Config.noParticles && !ParticleFilter.keep(parameters)) ci.cancel();
    }

    @Inject(method = "addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;I)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void visualmod$noEmitterTimed(Entity entity, ParticleEffect parameters, int maxAge, CallbackInfo ci) {
        if (Config.noParticles && !ParticleFilter.keep(parameters)) ci.cancel();
    }
}
