package com.visualmod.mixin;

import com.visualmod.ItemStateExt;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/** Запоминает, лежит ли предмет на земле (для Item Physics). */
@Mixin(ItemEntityRenderState.class)
public class ItemEntityRenderStateMixin implements ItemStateExt {
    @Unique
    private boolean visualmod$onGround;

    @Override
    public boolean visualmod$isOnGround() {
        return visualmod$onGround;
    }

    @Override
    public void visualmod$setOnGround(boolean onGround) {
        this.visualmod$onGround = onGround;
    }
}
