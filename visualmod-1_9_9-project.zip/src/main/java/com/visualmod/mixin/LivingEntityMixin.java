package com.visualmod.mixin;

import com.visualmod.Config;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Swing Animation: скорость взмаха руки игрока (только визуально). */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "getHandSwingDuration()I", at = @At("HEAD"), cancellable = true, require = 0)
    private void visualmod$swingDuration(CallbackInfoReturnable<Integer> cir) {
        if (Config.swingAnim && (Object) this instanceof ClientPlayerEntity) {
            cir.setReturnValue(Math.max(1, Math.round(Config.swingSpeed)));
        }
    }
}
