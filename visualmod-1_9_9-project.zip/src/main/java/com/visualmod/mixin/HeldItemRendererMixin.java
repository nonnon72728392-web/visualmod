package com.visualmod.mixin;

import com.visualmod.Config;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** ViewModel (положение/размер предмета) и дополнительный наклон при взмахе. */
@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"), require = 0)
    private void visualmod$viewModel(AbstractClientPlayerEntity player, float tickDelta, float pitch,
                                     Hand hand, float swingProgress, ItemStack item, float equipProgress,
                                     MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                     CallbackInfo ci) {
        Arm arm = hand == Hand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        float side = arm == Arm.RIGHT ? 1.0f : -1.0f;

        if (Config.viewModel) {
            matrices.translate(Config.vmX * side, Config.vmY, Config.vmZ);
            matrices.scale(Config.vmScale, Config.vmScale, Config.vmScale);
        }

        if (Config.swingAnim && swingProgress > 0.0f && Config.swingAngle != 0.0f) {
            float s = (float) Math.sin(swingProgress * Math.PI);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-Config.swingAngle * s));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(Config.swingAngle * 0.5f * s * side));
        }
    }

    /**
     * Стили взмаха. Vanilla не трогаем; Sideways и Push полностью заменяют ванильный взмах предмета.
     */
    @Inject(method = "applySwingOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void visualmod$swingStyle(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        if (!Config.swingAnim || Config.swingStyle == 0) return;

        int i = arm == Arm.RIGHT ? 1 : -1;
        float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);

        if (Config.swingStyle == 1) {
            // Sideways: предмет рубит боком, поперёк экрана
            matrices.translate(-i * g * 0.45f, g * 0.05f, -g * 0.10f);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * g * 60.0f));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-i * g * 30.0f));
        } else {
            // Push: толчок вперёд-вниз, как при установке блока
            matrices.translate(0.0f, -g * 0.12f, -g * 0.45f);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-g * 28.0f));
        }
        ci.cancel();
    }
}
