package com.visualmod;

import net.minecraft.client.MinecraftClient;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Список всех модулей (один источник правды для меню и для клавиш включения). */
public final class Modules {
    private Modules() {}

    public record Mod(String id, String label, BooleanSupplier get, Consumer<Boolean> set) {}

    private static final Map<String, Mod> MODS = new LinkedHashMap<>();
    private static final Map<String, Boolean> DOWN = new HashMap<>();

    private static void add(String id, String label, BooleanSupplier g, Consumer<Boolean> s) {
        MODS.put(id, new Mod(id, label, g, s));
    }

    static {
        add("esp", "ESP", () -> Config.esp, v -> Config.esp = v);
        add("seeinv", "See invisibles", () -> Config.seeInvisibles, v -> Config.seeInvisibles = v);
        add("nametags", "NameTags", () -> Config.nameTags, v -> Config.nameTags = v);
        add("fullbright", "Fullbright", () -> Config.fullbright, v -> Config.fullbright = v);
        add("itemphysics", "Item Physics", () -> Config.itemPhysics, v -> Config.itemPhysics = v);
        add("jumpcircle", "Jump Circle", () -> Config.jumpCircle, v -> Config.jumpCircle = v);
        add("chinahat", "China Hat", () -> Config.chinaHat, v -> Config.chinaHat = v);
        add("noparticles", "No Particles", () -> Config.noParticles, v -> Config.noParticles = v);
        add("nohurtcam", "No Hurt Cam", () -> Config.noHurtCam, v -> Config.noHurtCam = v);
        add("nofire", "No Fire Overlay", () -> Config.noFire, v -> Config.noFire = v);
        add("zoom", "Zoom", () -> Config.zoom, v -> Config.zoom = v);
        add("viewmodel", "ViewModel", () -> Config.viewModel, v -> Config.viewModel = v);
        add("swing", "Swing Animation", () -> Config.swingAnim, v -> Config.swingAnim = v);
        add("hitinfo", "Hit Info", () -> Config.hitInfo, v -> Config.hitInfo = v);
        add("triggerbot", "Trigger Bot", () -> Config.triggerBot, v -> Config.triggerBot = v);
        add("autototem", "Auto Totem", () -> Config.autoTotem, v -> Config.autoTotem = v);
        add("clickpearl", "Click Pearl", () -> Config.clickPearl, v -> Config.clickPearl = v);
        add("clickwind", "Click Wind Charge", () -> Config.clickWind, v -> Config.clickWind = v);
        add("autosprint", "Auto Sprint", () -> Config.autoSprint, v -> Config.autoSprint = v);
        add("autorespawn", "Auto Respawn", () -> Config.autoRespawn, v -> Config.autoRespawn = v);
    }

    public static Mod get(String id) {
        return MODS.get(id);
    }

    public static Collection<Mod> all() {
        return MODS.values();
    }

    /** Клавиши включения/выключения модулей (работают только когда нет открытого экрана). */
    public static void tick(MinecraftClient mc) {
        boolean free = mc.currentScreen == null && mc.player != null;
        for (Mod m : MODS.values()) {
            int code = Config.bind(m.id());
            boolean d = free && code != -1 && Actions.isDown(mc, code);
            if (d && !DOWN.getOrDefault(m.id(), false)) {
                m.set().accept(!m.get().getAsBoolean());
            }
            DOWN.put(m.id(), d);
        }
    }
}
