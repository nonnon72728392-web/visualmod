package com.visualmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

/** Click Pearl, Click Wind Charge, Auto Totem, Auto Respawn. */
public final class Actions {
    private Actions() {}

    private static boolean pearlDown = false;
    private static boolean windDown = false;
    private static long lastUse = 0L;
    private static int totemCd = 0;
    private static int deadTicks = 0;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            pearlDown = false;
            windDown = false;
            return;
        }

        if (Config.autoRespawn && mc.currentScreen instanceof DeathScreen) {
            if (++deadTicks >= Math.round(Config.arDelay)) {
                p.requestRespawn();
                mc.setScreen(null);
                deadTicks = 0;
            }
            return;
        }
        deadTicks = 0;

        tickBind(mc);
        tickTotem(mc, p);
    }

    // ------------------------------------------------------------ бинды (клавиша или кнопка мыши)

    public static boolean isDown(MinecraftClient mc, int code) {
        if (code == -1) return false;
        long h = mc.getWindow().getHandle();
        if (code <= -100) return GLFW.glfwGetMouseButton(h, -100 - code) == GLFW.GLFW_PRESS;
        return GLFW.glfwGetKey(h, code) == GLFW.GLFW_PRESS;
    }

    private static void tickBind(MinecraftClient mc) {
        boolean free = mc.currentScreen == null;

        boolean pd = free && Config.clickPearl && isDown(mc, Config.cpBind);
        if (pd && !pearlDown) use(mc, Items.ENDER_PEARL, false, Config.cpSwing);
        pearlDown = pd;

        boolean wd = free && Config.clickWind && isDown(mc, Config.cwBind);
        if (wd && !windDown) use(mc, Items.WIND_CHARGE, Config.cwAimDown, Config.cwSwing);
        windDown = wd;
    }

    /** Берёт предмет из хотбара (или левой руки), использует и возвращает слот на место. */
    private static void use(MinecraftClient mc, Item item, boolean aimDown, boolean swing) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        long now = System.currentTimeMillis();
        if (now - lastUse < 150L) return;

        PlayerInventory inv = p.getInventory();
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(item)) {
                slot = i;
                break;
            }
        }
        boolean offhand = p.getOffHandStack().isOf(item);
        if (slot < 0 && !offhand) return;

        ItemStack stack = slot >= 0 ? inv.getStack(slot) : p.getOffHandStack();
        if (p.getItemCooldownManager().isCoolingDown(stack)) return;

        Hand hand = slot >= 0 ? Hand.MAIN_HAND : Hand.OFF_HAND;
        int prevSlot = inv.selectedSlot;
        float prevPitch = p.getPitch();

        if (slot >= 0) inv.selectedSlot = slot;
        if (aimDown) p.setPitch(90.0f);

        mc.interactionManager.interactItem(p, hand);
        if (swing) p.swingHand(hand);

        if (aimDown) p.setPitch(prevPitch);
        inv.selectedSlot = prevSlot;   // на сервер уйдёт при следующей синхронизации слота
        lastUse = now;
    }

    // ------------------------------------------------------------ Auto Totem

    private static void tickTotem(MinecraftClient mc, ClientPlayerEntity p) {
        if (!Config.autoTotem || mc.interactionManager == null) return;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            totemCd = 0;
            return;
        }
        if (Config.atEmptyOnly && !p.getOffHandStack().isEmpty()) return;
        if (Config.atHealth > 0.0f && p.getHealth() + p.getAbsorptionAmount() > Config.atHealth) return;
        if (mc.currentScreen != null && !(mc.currentScreen instanceof InventoryScreen)) return;
        if (totemCd > 0) {
            totemCd--;
            return;
        }

        PlayerInventory inv = p.getInventory();
        int found = -1;
        for (int i = 9; i < 36 && found < 0; i++) {
            if (inv.getStack(i).isOf(Items.TOTEM_OF_UNDYING)) found = i;
        }
        for (int i = 0; i < 9 && found < 0; i++) {
            if (inv.getStack(i).isOf(Items.TOTEM_OF_UNDYING)) found = i;
        }
        if (found < 0) return;

        int slotId = found < 9 ? 36 + found : found;   // номер слота в PlayerScreenHandler
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slotId, 40, SlotActionType.SWAP, p);
        totemCd = Math.max(1, Math.round(Config.atDelay));
    }
}
