package com.visualmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Trigger Bot: бьёт цель под прицелом, когда удар заряжен. */
public final class TriggerBot {
    private TriggerBot() {}

    private static int ready = 0;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!Config.triggerBot || p == null || mc.world == null || mc.interactionManager == null
                || mc.currentScreen != null || p.isUsingItem() || p.isSpectator()) {
            ready = 0;
            return;
        }
        HitResult hr = mc.crosshairTarget;
        if (!(hr instanceof EntityHitResult ehr)) {
            ready = 0;
            return;
        }
        Entity e = ehr.getEntity();
        if (e == p || !(e instanceof LivingEntity le) || !le.isAlive() || !le.isAttackable()) {
            ready = 0;
            return;
        }
        if (Config.tbPlayersOnly && !(e instanceof PlayerEntity)) {
            ready = 0;
            return;
        }
        if (p.getAttackCooldownProgress(0.5f) < Config.tbCharge) return;
        if (ready++ < Math.round(Config.tbDelay)) return;

        mc.interactionManager.attackEntity(p, e);
        p.swingHand(Hand.MAIN_HAND);
        ready = 0;
    }
}
