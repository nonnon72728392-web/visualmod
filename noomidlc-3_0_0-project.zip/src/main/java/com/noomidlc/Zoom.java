package com.noomidlc;

import net.minecraft.client.MinecraftClient;

/** Zoom: пока зажата клавиша, FOV плавно уменьшается. */
public final class Zoom {
    private Zoom() {}

    private static boolean held = false;
    private static float t = 0.0f;

    public static void tick(MinecraftClient mc) {
        held = Config.zoom && mc.player != null && mc.currentScreen == null
                && Actions.isDown(mc, Config.zoomBind);
    }

    /** Вызывается из миксина GameRenderer.getFov. */
    public static double apply(double fov) {
        Anim.frame();
        float target = held ? 1.0f : 0.0f;
        t = Config.zoomSmooth ? Anim.smooth(t, target, 16.0f) : target;
        if (t <= 0.001f) return fov;
        double level = Math.max(1.0f, Config.zoomLevel);
        return fov / (1.0 + (level - 1.0) * t);
    }
}
