package com.noomidlc;

import net.minecraft.util.math.MathHelper;

/** Custom Sky: цвет неба / тумана / облаков и время суток (только на экране игрока). */
public final class Sky {
    private Sky() {}

    private static final long[] TIMES = {0L, 23000L, 1000L, 6000L, 12600L, 14500L, 18000L};

    public static boolean colorOn() {
        return Config.sky && Config.skyMode != 4;
    }

    /** RGB неба (0xRRGGBB). */
    public static int rgb() {
        long now = System.currentTimeMillis();
        switch (Config.skyMode) {
            case 1:
                return MathHelper.hsvToRgb(Config.skyHue, Config.skySat, Math.min(1.0f, Config.skyBright)) & 0xFFFFFF;
            case 2: {   // аврора: бирюзовый - фиолетовый - розовый
                float h = 0.48f + 0.28f * (0.5f + 0.5f * (float) Math.sin(now / 5200.0));
                return MathHelper.hsvToRgb(h, 0.62f, Math.min(1.0f, 0.55f + 0.45f * Config.skyBright)) & 0xFFFFFF;
            }
            case 3: {   // закат: оранжевый - розовый
                float k = 0.5f + 0.5f * (float) Math.sin(now / 6000.0);
                return Ui.mix(0xFFFF8A4C, 0xFFFF5E9A, k) & 0xFFFFFF;
            }
            default:
                return Config.flow(0.0f) & 0xFFFFFF;
        }
    }

    public static int scale(int rgb, float k) {
        int r = Math.min(255, Math.round(((rgb >> 16) & 255) * k));
        int g = Math.min(255, Math.round(((rgb >> 8) & 255) * k));
        int b = Math.min(255, Math.round((rgb & 255) * k));
        return (r << 16) | (g << 8) | b;
    }

    /** Время суток вместо серверного. */
    public static long time(long original) {
        if (!Config.sky || Config.skyTime == 0) return original;
        if (Config.skyTime >= TIMES.length) {   // Timelapse
            return (long) ((System.currentTimeMillis() / 50.0 * Config.skySpeed * 8.0) % 24000.0);
        }
        return TIMES[Config.skyTime];
    }
}
