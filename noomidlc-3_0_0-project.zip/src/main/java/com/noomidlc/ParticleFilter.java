package com.noomidlc;

import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleType;
import net.minecraft.particle.ParticleTypes;

/** Решает, какие частицы оставить при включённом No Particles. */
public final class ParticleFilter {
    private ParticleFilter() {}

    public static boolean anyKept() {
        return Config.npKeepTotem || Config.npKeepHit;
    }

    /** true = частицу надо оставить. */
    public static boolean keep(ParticleEffect effect) {
        if (!anyKept()) return false;
        ParticleType<?> type = effect.getType();
        if (Config.npKeepTotem && type == ParticleTypes.TOTEM_OF_UNDYING) return true;
        return Config.npKeepHit && (type == ParticleTypes.CRIT
                || type == ParticleTypes.ENCHANTED_HIT
                || type == ParticleTypes.DAMAGE_INDICATOR);
    }
}
