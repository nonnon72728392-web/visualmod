package com.noomidlc;

/** Плавные анимации: экспоненциальное сглаживание с учётом времени кадра. */
public final class Anim {
    private Anim() {}

    private static long last = System.nanoTime();
    private static float dt = 0.016f;

    /** Обновляет время кадра. Безопасно вызывать несколько раз за кадр. */
    public static void frame() {
        long n = System.nanoTime();
        if (n - last < 2_000_000L) return;
        dt = Math.min(0.1f, (n - last) / 1.0e9f);
        last = n;
    }

    public static float dt() {
        return dt;
    }

    /** Всегда сглаживает (не зависит от настройки анимаций меню). */
    public static float smooth(float cur, float target, float speed) {
        float k = 1.0f - (float) Math.exp(-speed * dt);
        float v = cur + (target - cur) * k;
        return Math.abs(target - v) < 0.002f ? target : v;
    }

    /** Анимация интерфейса: если анимации выключены, сразу возвращает цель. */
    public static float step(float cur, float target, float speed) {
        return Config.uiAnim ? smooth(cur, target, speed) : target;
    }

    public static float ease(float v) {
        float t = 1.0f - Math.max(0.0f, Math.min(1.0f, v));
        return 1.0f - t * t * t;
    }
}
