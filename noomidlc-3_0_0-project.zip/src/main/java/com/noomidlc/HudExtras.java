package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Дополнительные HUD-панели: цель и локальный радар игроков. */
public final class HudExtras {
    private HudExtras() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int accent = Config.accent();

        if (Config.hudTarget) {
            PlayerEntity target = KillAura.target() instanceof PlayerEntity p ? p : null;
            if (target != null && target.isAlive()) {
                int w = 142, h = 38, x = sw / 2 - w / 2, y = sh / 2 + 34;
                ctx.fill(x, y, x + w, y + h, 0xC9101018);
                ctx.fill(x, y, x + 2, y + h, accent);
                String name = target.getName().getString();
                ctx.drawText(mc.textRenderer, name, x + 8, y + 6, 0xFFFFFFFF, true);
                float max = Math.max(1.0f, target.getMaxHealth());
                float health = MathHelper.clamp(target.getHealth() / max, 0.0f, 1.0f);
                ctx.fill(x + 8, y + 22, x + w - 8, y + 28, 0xFF353541);
                ctx.fill(x + 8, y + 22, x + 8 + Math.round((w - 16) * health), y + 28,
                        health > 0.5f ? 0xFF55DD88 : health > 0.25f ? 0xFFFFC04D : 0xFFFF5555);
                String hp = String.format(java.util.Locale.ROOT, "%.1f HP", target.getHealth());
                ctx.drawText(mc.textRenderer, hp, x + w - 8 - mc.textRenderer.getWidth(hp), y + 6, 0xFFD8D8E8, true);
            }
        }

        if (Config.hudRadar) {
            int size = 94, x = sw - size - 12, y = 12, cx = x + size / 2, cy = y + size / 2;
            ctx.fill(x, y, x + size, y + size, 0xB9101018);
            ctx.fill(x, y, x + size, y + 1, accent);
            ctx.fill(cx - 1, y + 8, cx + 1, y + size - 8, 0x665E6475);
            ctx.fill(x + 8, cy - 1, x + size - 8, cy + 1, 0x665E6475);
            ctx.fill(cx - 2, cy - 2, cx + 2, cy + 2, 0xFFFFFFFF);

            Vec3d origin = mc.player.getPos();
            double yaw = Math.toRadians(mc.player.getYaw());
            double sin = Math.sin(yaw), cos = Math.cos(yaw);
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player || !p.isAlive()) continue;
                double dx = p.getX() - origin.x, dz = p.getZ() - origin.z;
                double rx = (dx * cos - dz * sin) / 32.0;
                double rz = (dx * sin + dz * cos) / 32.0;
                if (Math.abs(rx) > 1.0 || Math.abs(rz) > 1.0) continue;
                int px = cx + (int)Math.round(rx * 37.0);
                int py = cy + (int)Math.round(rz * 37.0);
                ctx.fill(px - 2, py - 2, px + 3, py + 3, 0xFFFF6666);
            }
            ctx.drawText(mc.textRenderer, "RADAR", x + 5, y + size + 3, 0xFFD8D8E8, true);
        }
    }
}
