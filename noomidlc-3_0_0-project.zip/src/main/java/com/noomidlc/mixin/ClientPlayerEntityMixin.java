package com.noomidlc.mixin;

import com.noomidlc.Config;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** No Clip: ванильный PlayerEntity.tick сбрасывает noClip каждый тик, поэтому включаем его прямо перед движением. */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Inject(method = "tickMovement()V", at = @At("HEAD"), require = 0)
    private void noomidlc$noClip(CallbackInfo ci) {
        if (Config.noClip) {
            ((Entity) (Object) this).noClip = true;
        }
    }
}
