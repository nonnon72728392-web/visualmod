package com.noomidlc.mixin;

import com.noomidlc.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** ESP (режим Glow): включает ванильную обводку для живых существ. */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Shadow public ClientPlayerEntity player;

    @Inject(method = "hasOutline(Lnet/minecraft/entity/Entity;)Z", at = @At("HEAD"), cancellable = true, require = 0)
    private void noomidlc$esp(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (Config.esp && Config.espMode == 1 && entity instanceof LivingEntity && entity != this.player) {
            cir.setReturnValue(true);
        }
    }
}
