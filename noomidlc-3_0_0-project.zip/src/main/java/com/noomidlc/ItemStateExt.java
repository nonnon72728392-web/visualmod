package com.noomidlc;

/** Интерфейс, который через миксин добавляется в ItemEntityRenderState. */
public interface ItemStateExt {
    boolean noomidlc$isOnGround();

    void noomidlc$setOnGround(boolean onGround);
}
