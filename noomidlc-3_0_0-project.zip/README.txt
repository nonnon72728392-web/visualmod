noomidlc 3.0.0 — Fabric / Minecraft 1.21.4

Новые элементы:
- Target HUD: карточка выбранной KillAura цели (имя и здоровье).
- Player Radar: мини-радар игроков в радиусе примерно 32 блоков.
- Настройки находятся в Right Shift → HUD.

Функции из запроса, уже присутствующие в базовом проекте:
- Chest ESP — Block ESP → Chests / barrels.
- Tracers — Visuals → ESP → Tracers.
- AutoTotem — Combat → Auto Totem.
- AutoSprint и NoFall — Misc.
- Potion HUD и Keystrokes — HUD.

Важно:
- Некоторые функции (AutoTotem, NoFall, AutoSprint, KillAura и ESP) могут нарушать правила серверов.
- Исходники обновлены; сборка Gradle в этой среде не запускалась и совместимость не подтверждена.
- Для сборки используй JDK 21 и Gradle task `build`; результат ожидается в build/libs/.
