VisualMod 2.1.0 (Fabric 1.21.4)

Что нового в 2.1.0:
- Новая вкладка меню Extra: Kill Effect, быстрые переключатели ESP (3D Box / Skeleton / Tracers), круг FOV
- Kill Effect (Extra): эффект в месте гибели цели - Lightning / Explosion / Souls / Shockwave / Firework;
  настройки Color / Amount / Size, Only my kills, Include mobs
- ESP: два новых режима - 3D Box (настоящий объёмный бокс) и Skeleton (палочный скелет), имя/дистанция/HP работают в них тоже
- Aim Assist (Combat): мягко подтягивает прицел к цели в конусе FOV; Range / FOV / Strength / Aim at (Head, Chest, Closest),
  Only while attacking, Weapon only, Vertical, Humanize, круг FOV на экране
- Код новых модулей: KillFx.java, AimAssist.java; правки в Esp.java, Config.java, Modules.java, ClickGuiScreen.java, VisualMod.java

VisualMod 2.0.0 (Fabric 1.21.4, Loom 1.9, yarn-маппинги)

Что нового в 2.0.0:
- Kill Aura (Combat): ближайшая цель в радиусе, плавный поворот, удар по зарядке; настройки Range / Charge / Delay / FOV / Turn speed / Sort, Mobs, Walls, Rotate; анимированное кольцо на цели
- ESP: режимы Corners / Glow / Fancy (градиентная заливка, мягкое свечение, пульсация, имя+дистанция, градиентная полоска HP, трассеры)
- Particles (World): собственные светящиеся частицы - Hit burst / Orbit / Trail / All
- Swing Animation: 10 стилей (Vanilla, Sideways, Push, Slash, Spin, Stab, Whip, Smooth, Chop, Wave) + Bounce
- Новое меню: плавающие панели-категории. ПКМ по модулю - раскрыть настройки, ПКМ по заголовку - свернуть, колесо - прокрутка.
  Эффекты: фоновые частицы с линиями, след курсора, волна от клика, свечение включённых модулей, выезд панелей, бегущая линия заголовка.
  Включаются/выключаются во вкладке Style.

VisualMod 1.9.1 (Fabric 1.21.4, Loom 1.9, yarn-маппинги)

Сборка:  gradle build   (нужны Gradle 8.11+ и JDK 21; или ./gradlew build, если wrapper уже есть в вашем проекте)
Jar:     build/libs/visualmod-1.9.1.jar   (НЕ -sources)
Нужен Fabric API. Работает только на Minecraft 1.21.4.

Меню: Right Shift. ЛКМ по модулю - вкл/выкл, ПКМ - окно настроек этого модуля
(в каждом окне есть "Toggle key" - клавиша включения модуля).

Что нового в 1.9.1:
- Trigger Bot (Combat): бьёт цель под прицелом, когда удар заряжен; настройки Charge / Delay / Players only
- Potions: блок HUD со своими эффектами и таймерами (можно двигать), и эффекты зелий над никами других игроков (NameTags -> Potions)

Что было в 1.9.0:
- ПКМ-настройки у всех модулей и у всех блоков HUD, клавиша включения у каждого модуля
- Плавное меню: анимации переключателей, вкладок, окна настроек; шрифт подбирается под масштаб GUI
  (oversample = масштаб), текст привязан к физическим пикселям - без "лесенки"
- Hit Info: урон, последний удар, сколько цель восстановила (+), полоска HP, всё настраивается
- No Particles: убирает все частицы, можно оставить тотем / частицы ударов
- Новые модули: Zoom (зажать клавишу, по умолчанию C), No Fire Overlay, Armor HUD, Item Counters (тотемы/перлы/заряды ветра)
- Плавный список модулей, цвет ESP (Accent/Rainbow/White), задержка Auto Respawn
- Все миксины с require = 0: если метод не найден в вашей версии, функция просто не работает, а игра не падает

Если у вас уже есть свой проект - замените src/main/java и src/main/resources файлами из этого архива.
