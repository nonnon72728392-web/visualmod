package dev.voidclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;

/**
 * Automatically selects the hotbar tool with the best mining speed for the
 * block currently being mined. Restores the previous slot when mining stops.
 */
public final class AutoTool {
    private AutoTool() {}

    private static int previousSlot = -1;
    private static boolean switched = false;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || mc.currentScreen != null
                || !Config.autoTool || !mc.options.attackKey.isPressed()
                || !(mc.crosshairTarget instanceof BlockHitResult hit)
                || mc.crosshairTarget.getType() != HitResult.Type.BLOCK) {
            restore(player);
            return;
        }

        BlockState state = mc.world.getBlockState(hit.getBlockPos());
        if (state.isAir()) {
            restore(player);
            return;
        }

        int bestSlot = player.getInventory().selectedSlot;
        float bestSpeed = player.getInventory().getStack(bestSlot).getMiningSpeedMultiplier(state);

        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = player.getInventory().getStack(slot);
            float speed = stack.getMiningSpeedMultiplier(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = slot;
            }
        }

        if (bestSlot != player.getInventory().selectedSlot) {
            if (!switched) {
                previousSlot = player.getInventory().selectedSlot;
                switched = true;
            }
            player.getInventory().selectedSlot = bestSlot;
        }
    }

    private static void restore(ClientPlayerEntity player) {
        if (switched && player != null && previousSlot >= 0 && previousSlot < 9) {
            player.getInventory().selectedSlot = previousSlot;
        }
        previousSlot = -1;
        switched = false;
    }
}
