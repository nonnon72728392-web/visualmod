package dev.voidclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;

import java.util.Random;

/** No Fall, Jesus, Anti AFK (Reach - миксин PlayerEntityMixin, No Clip - ClientPlayerEntityMixin + Movement). */
public final class Misc {
    private Misc() {}

    private static final Random RND = new Random();
    private static int afkTicks = 0;
    private static int afkJumpRelease = 0;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            afkTicks = 0;
            afkJumpRelease = 0;
            return;
        }
        noFall(mc, p);
        jesus(mc, p);
        antiAfk(mc, p);
    }

    // ------------------------------------------------------------ No Fall

    private static boolean gliding(ClientPlayerEntity p) {
        String n = p.getPose().name();
        return n.equals("GLIDING") || n.equals("FALL_FLYING");
    }

    private static void noFall(MinecraftClient mc, ClientPlayerEntity p) {
        if (!Config.noFall || mc.getNetworkHandler() == null) return;
        if (p.getAbilities().flying || p.isTouchingWater() || p.isClimbing() || gliding(p)) return;
        if (p.isOnGround() || p.getVelocity().y > -0.1) return;
        if (p.fallDistance >= Config.nfDistance) {
            // говорим серверу, что мы на земле: у него сбрасывается накопленная высота падения
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
            p.fallDistance = 0.0f;
        }
    }

    // ------------------------------------------------------------ Jesus

    private static boolean walkable(MinecraftClient mc, BlockPos pos) {
        FluidState f = mc.world.getFluidState(pos);
        if (f.isEmpty()) return false;
        return f.isIn(FluidTags.WATER) || (Config.jesusLava && f.isIn(FluidTags.LAVA));
    }

    private static void jesus(MinecraftClient mc, ClientPlayerEntity p) {
        if (!Config.jesus || Config.noClip || Config.fly || Config.airStuck) return;
        if (p.getAbilities().flying || p.isSneaking() || mc.options.jumpKey.isPressed()) return;

        BlockPos feet = p.getBlockPos();
        BlockPos below = BlockPos.ofFloored(p.getX(), p.getY() - 0.15, p.getZ());
        boolean inFluid = walkable(mc, feet) || p.isTouchingWater();
        boolean over = walkable(mc, below);

        double vx = p.getVelocity().x, vy = p.getVelocity().y, vz = p.getVelocity().z;
        double k = Config.jesusSpeed;
        if (inFluid) {
            // провалились - выталкиваем наверх
            p.setVelocity(vx * k, Math.max(vy, 0.12), vz * k);
            p.fallDistance = 0.0f;
        } else if (over && vy <= 0.0) {
            // стоим на поверхности: гасим падение, лёгкий дребезг каждые ~1.5 с сбрасывает серверный "floating"
            boolean dip = (p.age % 30) == 0;
            p.setVelocity(vx * k, dip ? -0.1 : 0.0, vz * k);
            p.fallDistance = 0.0f;
        }
    }

    // ------------------------------------------------------------ Anti AFK

    private static void antiAfk(MinecraftClient mc, ClientPlayerEntity p) {
        if (afkJumpRelease > 0 && --afkJumpRelease == 0) {
            mc.options.jumpKey.setPressed(false);
        }
        if (!Config.antiAfk || mc.currentScreen != null) {
            afkTicks = 0;
            return;
        }
        // любое реальное движение мышью/клавишами сбрасывает таймер
        if (mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
                || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed()) {
            afkTicks = 0;
            return;
        }
        if (++afkTicks < Math.max(1.0f, Config.afkInterval) * 20.0f) return;
        afkTicks = 0;

        if (Config.afkRotate) {
            float d = (6.0f + RND.nextFloat() * 14.0f) * (RND.nextBoolean() ? 1.0f : -1.0f);
            p.setYaw(p.getYaw() + d);
            p.setPitch(Math.max(-60.0f, Math.min(60.0f, p.getPitch() + (RND.nextFloat() - 0.5f) * 6.0f)));
        }
        if (Config.afkJump && p.isOnGround()) {
            mc.options.jumpKey.setPressed(true);
            afkJumpRelease = 2;
        }
        if (Config.afkSwing) p.swingHand(Hand.MAIN_HAND);
    }
}
