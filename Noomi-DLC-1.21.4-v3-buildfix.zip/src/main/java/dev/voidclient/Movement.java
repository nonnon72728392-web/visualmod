package dev.voidclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EntityPose;
import net.minecraft.util.math.Vec3d;

/** Fly, Spider, Air Swim, Air Stuck (No Web сделан миксином EntityMixin). */
public final class Movement {
    private Movement() {}

    private static boolean gravityOff = false;
    private static boolean stuck = false;
    private static double sx, sy, sz;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            gravityOff = false;
            stuck = false;
            return;
        }
        boolean free = mc.currentScreen == null;

        // ---- Air Stuck: замираем в той точке, где включили
        if (Config.airStuck) {
            if (!stuck) {
                sx = p.getX();
                sy = p.getY();
                sz = p.getZ();
                stuck = true;
            }
            p.setPosition(sx, sy, sz);
            p.setVelocity(0.0, 0.0, 0.0);
            p.fallDistance = 0;
            gravity(p, true);
            return;
        }
        stuck = false;

        // ---- No Clip: летим сквозь блоки (сама "прозрачность" включается в ClientPlayerEntityMixin)
        if (Config.noClip) {
            double fwd = 0.0, str = 0.0, up = 0.0;
            if (free) {
                if (mc.options.forwardKey.isPressed()) fwd += 1.0;
                if (mc.options.backKey.isPressed()) fwd -= 1.0;
                if (mc.options.leftKey.isPressed()) str += 1.0;
                if (mc.options.rightKey.isPressed()) str -= 1.0;
                if (mc.options.jumpKey.isPressed()) up += 1.0;
                if (mc.options.sneakKey.isPressed()) up -= 1.0;
            }
            double len = Math.sqrt(fwd * fwd + str * str);
            if (len > 1.0) {
                fwd /= len;
                str /= len;
            }
            double yaw = Math.toRadians(p.getYaw());
            double sin = Math.sin(yaw), cos = Math.cos(yaw);
            p.setVelocity((-sin * fwd + cos * str) * Config.ncSpeed, up * Config.ncVert, (cos * fwd + sin * str) * Config.ncSpeed);
            p.fallDistance = 0;
            gravity(p, true);
            return;
        }

        // ---- Fly
        if (Config.fly) {
            double fwd = 0.0, str = 0.0, up = 0.0;
            if (free) {
                if (mc.options.forwardKey.isPressed()) fwd += 1.0;
                if (mc.options.backKey.isPressed()) fwd -= 1.0;
                if (mc.options.leftKey.isPressed()) str += 1.0;
                if (mc.options.rightKey.isPressed()) str -= 1.0;
                if (mc.options.jumpKey.isPressed()) up += 1.0;
                if (mc.options.sneakKey.isPressed()) up -= 1.0;
            }
            double len = Math.sqrt(fwd * fwd + str * str);
            if (len > 1.0) {
                fwd /= len;
                str /= len;
            }
            double yaw = Math.toRadians(p.getYaw());
            double sin = Math.sin(yaw), cos = Math.cos(yaw);
            double vx = (-sin * fwd + cos * str) * Config.flySpeed;
            double vz = (cos * fwd + sin * str) * Config.flySpeed;
            p.setVelocity(vx, up * Config.flyVert, vz);
            p.fallDistance = 0;
            gravity(p, true);
            return;
        }

        // ---- Air Swim: плывём по воздуху в сторону взгляда
        if (Config.airSwim && !p.isOnGround() && !p.isTouchingWater() && !p.isClimbing()) {
            Vec3d look = p.getRotationVector();
            boolean fwd = free && mc.options.forwardKey.isPressed();
            if (fwd) {
                p.setVelocity(look.x * Config.asSpeed, look.y * Config.asSpeed, look.z * Config.asSpeed);
            } else {
                Vec3d v = p.getVelocity();
                p.setVelocity(v.x * 0.8, Math.max(v.y, -0.04), v.z * 0.8);
            }
            p.fallDistance = 0;
            p.setSwimming(true);
            p.setPose(EntityPose.SWIMMING);
            gravity(p, true);
            return;
        }

        gravity(p, false);

        // ---- Spider: лезем по стене, пока упираемся в неё
        if (Config.spider && p.horizontalCollision) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, Config.spiderSpeed, v.z);
            p.fallDistance = 0;
        }
    }

    private static void gravity(ClientPlayerEntity p, boolean off) {
        if (off) {
            p.setNoGravity(true);
            gravityOff = true;
        } else if (gravityOff) {
            p.setNoGravity(false);
            gravityOff = false;
        }
    }
}
