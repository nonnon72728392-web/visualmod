package dev.voidclient;

/** Интерфейс, который через миксин добавляется в ItemEntityRenderState. */
public interface ItemStateExt {
    boolean noomi_dlc$isOnGround();

    void noomi_dlc$setOnGround(boolean onGround);
}
