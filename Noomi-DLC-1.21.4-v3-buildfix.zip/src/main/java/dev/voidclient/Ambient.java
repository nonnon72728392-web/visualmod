package dev.voidclient;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Ambient: атмосферные частицы вокруг игрока - светлячки, снег, угольки, лепестки, пылинки.
 * Свои частицы (не ванильные), мягкое свечение, плавное появление и затухание, прячутся за блоками.
 */
public final class Ambient {
    private Ambient() {}

    private static final class P {
        float x, y, z, vx, vy, vz, size, phase, hue;
        int life, max;
    }

    private static final List<P> LIST = new ArrayList<>();
    private static final Random R = new Random();
    private static int n = 0;
    private static int lastMode = -1;
    private static final double RANGE = 18.0;

    private static boolean additive() {
        return Config.amMode == 0 || Config.amMode == 2 || Config.amMode == 4;
    }

    // ------------------------------------------------------------ логика

    public static void tick(MinecraftClient mc) {
        if (!Config.ambient || mc.world == null || mc.player == null) {
            LIST.clear();
            lastMode = -1;
            return;
        }
        if (lastMode != Config.amMode) {
            LIST.clear();
            lastMode = Config.amMode;
        }
        n++;
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        int target = Math.max(10, Math.round(Config.amCount));

        for (int i = LIST.size() - 1; i >= 0; i--) {
            P q = LIST.get(i);
            double dx = q.x - px, dz = q.z - pz;
            if (++q.life >= q.max || dx * dx + dz * dz > (RANGE + 6.0) * (RANGE + 6.0) || Math.abs(q.y - py) > 24.0) {
                LIST.remove(i);
                continue;
            }
            step(q);
            if ((Config.amMode == 1 || Config.amMode == 3) && ((n + i) & 3) == 0) {
                int top = mc.world.getTopY(Heightmap.Type.MOTION_BLOCKING, MathHelper.floor(q.x), MathHelper.floor(q.z));
                if (q.y < top + 0.05) q.life = q.max;   // долетел до земли или крыши
            }
        }

        int spawn = Math.min(14, target - LIST.size());
        for (int i = 0; i < spawn; i++) spawn(mc, px, py, pz);
    }

    private static void spawn(MinecraftClient mc, double px, double py, double pz) {
        double a = R.nextDouble() * Math.PI * 2.0;
        double d = Math.sqrt(R.nextDouble()) * RANGE;
        double x = px + Math.cos(a) * d, z = pz + Math.sin(a) * d;
        int top = mc.world.getTopY(Heightmap.Type.MOTION_BLOCKING, MathHelper.floor(x), MathHelper.floor(z));
        P q = new P();
        q.x = (float) x;
        q.z = (float) z;
        q.phase = R.nextFloat() * 6.2831f;
        q.hue = R.nextFloat();
        switch (Config.amMode) {
            case 1 -> {   // снег: сверху, только там, где над головой небо / крыша выше
                double y = Math.max(py + 3.0, top + 2.0) + R.nextDouble() * 9.0;
                if (y < top + 1.0) return;
                q.y = (float) y;
                q.size = 0.028f + R.nextFloat() * 0.03f;
                q.max = 260 + R.nextInt(160);
                q.vy = -0.03f - R.nextFloat() * 0.025f;
            }
            case 2 -> {   // угольки: поднимаются
                q.y = (float) (Math.max(py - 1.0, top) + R.nextDouble() * 2.0);
                q.size = 0.03f + R.nextFloat() * 0.03f;
                q.max = 70 + R.nextInt(70);
                q.vy = 0.02f + R.nextFloat() * 0.03f;
            }
            case 3 -> {   // лепестки: плавно кружат вниз
                q.y = (float) (Math.max(py + 2.0, top + 2.0) + R.nextDouble() * 7.0);
                q.size = 0.05f + R.nextFloat() * 0.035f;
                q.max = 300 + R.nextInt(160);
                q.vy = -0.018f - R.nextFloat() * 0.012f;
            }
            case 4 -> {   // пылинки: висят в воздухе у игрока
                q.y = (float) (py + R.nextDouble() * 4.5 - 0.5);
                q.size = 0.012f + R.nextFloat() * 0.014f;
                q.max = 160 + R.nextInt(160);
            }
            default -> {  // светлячки: над землёй
                q.y = (float) (top + 0.4 + R.nextDouble() * 2.6);
                if (Math.abs(q.y - py) > 12.0) return;
                q.size = 0.032f + R.nextFloat() * 0.02f;
                q.max = 220 + R.nextInt(220);
            }
        }
        LIST.add(q);
    }

    private static void step(P q) {
        float t = n * 0.03f + q.phase;
        switch (Config.amMode) {
            case 1 -> {
                q.vx = (float) Math.sin(t) * 0.012f;
                q.vz = (float) Math.cos(t * 0.8f) * 0.012f;
            }
            case 2 -> {
                q.vx = (float) Math.sin(t * 2.0f) * 0.012f;
                q.vz = (float) Math.cos(t * 1.7f) * 0.012f;
            }
            case 3 -> {
                q.vx = (float) Math.cos(t * 1.1f) * 0.02f;
                q.vz = (float) Math.sin(t * 0.9f) * 0.02f;
                q.phase += 0.02f;   // вращение лепестка
            }
            case 4 -> {
                q.vx = (float) Math.sin(t * 0.7f) * 0.004f;
                q.vz = (float) Math.cos(t * 0.6f) * 0.004f;
                q.vy = (float) Math.sin(t * 0.5f) * 0.003f;
            }
            default -> {
                q.vx = (float) Math.sin(t * 1.3f) * 0.014f + (float) Math.sin(t * 0.37f) * 0.01f;
                q.vz = (float) Math.cos(t * 1.1f) * 0.014f + (float) Math.cos(t * 0.41f) * 0.01f;
                q.vy = (float) Math.sin(t * 0.9f) * 0.008f;
            }
        }
        q.x += q.vx;
        q.y += q.vy;
        q.z += q.vz;
    }

    // ------------------------------------------------------------ цвет

    private static int rgb(P q) {
        if (Config.amColor == 1) return Config.accent() & 0xFFFFFF;
        if (Config.amColor == 2) return WorldFx.rgbOf(1, q.hue);
        switch (Config.amMode) {
            case 1: return 0xFFFFFF;
            case 2: return Ui.mix(0xFFFF8A2A, 0xFFFFD36B, q.hue) & 0xFFFFFF;
            case 3: return Ui.mix(0xFFFF9EC7, 0xFFFFD0E2, q.hue) & 0xFFFFFF;
            case 4: return 0xFFE9B8;
            default: return Ui.mix(0xFFB6FF4A, 0xFFEFFF6B, q.hue) & 0xFFFFFF;
        }
    }

    // ------------------------------------------------------------ рендер

    public static void render(WorldRenderContext ctx) {
        if (!Config.ambient || LIST.isEmpty()) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(true);
        Quaternionf rot = ctx.camera().getRotation();
        Vector3f right = new Vector3f(1.0f, 0.0f, 0.0f).rotate(rot);
        Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f).rotate(rot);

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f mat = ms.peek().getPositionMatrix();

        boolean add = additive();
        RenderSystem.enableBlend();
        if (add) RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        else RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        float sz = Config.amSize;
        for (P q : LIST) {
            float f = (q.life + td) / q.max;
            float fade = Math.min(1.0f, Math.min(f / 0.15f, (1.0f - f) / 0.25f));
            if (fade <= 0.0f) continue;
            float x = q.x + q.vx * td, y = q.y + q.vy * td, z = q.z + q.vz * td;
            int rgb = rgb(q);
            float s = q.size * sz;

            if (Config.amMode == 0) {          // светлячок: мерцает
                float blink = 0.25f + 0.75f * (float) Math.pow(0.5 + 0.5 * Math.sin((n + td) * 0.09 + q.phase * 3.0), 2.0);
                float a = fade * blink;
                quad(b, mat, x, y, z, right, up, 1.0f, 1.0f, s * 7.0f, rgb, a * 0.07f);
                quad(b, mat, x, y, z, right, up, 1.0f, 1.0f, s * 3.6f, rgb, a * 0.18f);
                quad(b, mat, x, y, z, right, up, 1.0f, 1.0f, s * 1.5f, rgb, a * 0.65f);
                quad(b, mat, x, y, z, right, up, 1.0f, 1.0f, s * 0.7f, 0xFFFFFF, a);
            } else if (Config.amMode == 2) {   // уголёк: остывает к концу жизни
                int hot = Ui.mix(0xFF000000 | rgb, 0xFFFF3A1A, f) & 0xFFFFFF;
                float flick = 0.7f + 0.3f * (float) Math.sin((n + td) * 0.7 + q.phase * 5.0);
                quad(b, mat, x, y, z, right, up, 1.0f, 1.0f, s * 4.0f, hot, fade * flick * 0.12f);
                quad(b, mat, x, y, z, right, up, 1.0f, 1.0f, s * 1.3f, hot, fade * flick);
            } else if (Config.amMode == 4) {   // пылинка: еле заметный блеск
                float tw = 0.35f + 0.65f * (float) Math.pow(0.5 + 0.5 * Math.sin((n + td) * 0.05 + q.phase * 4.0), 2.0);
                quad(b, mat, x, y, z, right, up, 1.0f, 1.0f, s * 3.0f, rgb, fade * tw * 0.08f);
                quad(b, mat, x, y, z, right, up, 1.0f, 1.0f, s, rgb, fade * tw * 0.75f);
            } else if (Config.amMode == 1) {   // снежинка
                quad(b, mat, x, y, z, right, up, 1.0f, 1.0f, s * 1.0f, rgb, fade * 0.9f);
                quad(b, mat, x, y, z, right, up, 1.0f, 1.0f, s * 2.0f, rgb, fade * 0.12f);
            } else {                           // лепесток: вращается, вытянутая форма
                float ang = q.phase * 3.0f + (n + td) * 0.05f;
                float cs = (float) Math.cos(ang), sn = (float) Math.sin(ang);
                Vector3f r2 = new Vector3f(right).mul(cs).add(new Vector3f(up).mul(sn));
                Vector3f u2 = new Vector3f(up).mul(cs).sub(new Vector3f(right).mul(sn));
                float flip = 0.35f + 0.65f * Math.abs((float) Math.sin((n + td) * 0.04 + q.phase));
                quad(b, mat, x, y, z, r2, u2, 1.0f, flip * 0.6f, s * 1.1f, rgb, fade * 0.95f);
            }
        }
        Ui.flush(b);

        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ms.pop();
    }

    private static void quad(BufferBuilder b, Matrix4f m, float x, float y, float z,
                             Vector3f r, Vector3f u, float kr, float ku, float s, int rgb, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255.0f)));
        if (a == 0) return;
        int col = (a << 24) | (rgb & 0xFFFFFF);
        float rx = r.x * s * kr, ry = r.y * s * kr, rz = r.z * s * kr;
        float ux = u.x * s * ku, uy = u.y * s * ku, uz = u.z * s * ku;
        b.vertex(m, x - rx - ux, y - ry - uy, z - rz - uz).color(col);
        b.vertex(m, x + rx - ux, y + ry - uy, z + rz - uz).color(col);
        b.vertex(m, x + rx + ux, y + ry + uy, z + rz + uz).color(col);
        b.vertex(m, x - rx + ux, y - ry + uy, z - rz + uz).color(col);
    }
}
