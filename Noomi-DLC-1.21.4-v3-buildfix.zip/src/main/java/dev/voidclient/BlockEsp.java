package dev.voidclient;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Block ESP: рамки сквозь стены вокруг руд, сундуков и спавнеров рядом.
 * Сканирование размазано по тикам (один слой по высоте за тик), поэтому не лагает.
 */
public final class BlockEsp {
    private BlockEsp() {}

    private record Found(int x, int y, int z, int rgb) {}

    private record Frame(float[] p, int rgb, float alpha) {}

    private static final Map<Block, Integer> ORES = new HashMap<>();
    private static final Map<Block, Boolean> RARE = new HashMap<>();

    private static void ore(boolean rare, int rgb, Block... blocks) {
        for (Block b : blocks) {
            ORES.put(b, rgb);
            RARE.put(b, rare);
        }
    }

    static {
        ore(true, 0x4AEDD9, Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE);
        ore(true, 0x17DD62, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE);
        ore(true, 0xA0522D, Blocks.ANCIENT_DEBRIS);
        ore(true, 0xFCEE4B, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE);
        ore(false, 0xD8AF93, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE);
        ore(false, 0x6E6E6E, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE);
        ore(false, 0x3B5BDB, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE);
        ore(false, 0xFF2A2A, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE);
        ore(false, 0xE07B53, Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE);
        ore(false, 0xE8E0D0, Blocks.NETHER_QUARTZ_ORE);
    }

    private static final List<Found> FOUND = new ArrayList<>();
    private static final List<Found> BUILD = new ArrayList<>();
    private static final List<Frame> FRAMES = new ArrayList<>();
    private static int layer = 0;
    private static int lastRange = -1;

    private static int rgbOf(BlockState st) {
        Block b = st.getBlock();
        if (Config.beOres) {
            Integer c = ORES.get(b);
            if (c != null && (!Config.beRare || RARE.getOrDefault(b, false))) return c;
        }
        if (Config.beChests) {
            if (b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.BARREL) return 0xFFB84D;
            if (b == Blocks.ENDER_CHEST) return 0xB070FF;
            if (b instanceof ShulkerBoxBlock) return 0xD27AF0;
        }
        if (Config.beSpawners && (b == Blocks.SPAWNER || b == Blocks.TRIAL_SPAWNER)) return 0xFF4D4D;
        return -1;
    }

    // ------------------------------------------------------------ сканирование

    public static void tick(MinecraftClient mc) {
        if (!Config.blockEsp || mc.world == null || mc.player == null) {
            if (!FOUND.isEmpty()) FOUND.clear();
            BUILD.clear();
            layer = 0;
            return;
        }
        int r = Math.max(4, Math.round(Config.beRange));
        if (r != lastRange) {
            lastRange = r;
            layer = 0;
            BUILD.clear();
        }
        BlockPos pc = mc.player.getBlockPos();
        int y = pc.getY() - r + layer;
        if (y >= mc.world.getBottomY() && y < mc.world.getBottomY() + mc.world.getHeight()) {
            BlockPos.Mutable m = new BlockPos.Mutable();
            int r2 = r * r;
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (dx * dx + dz * dz > r2) continue;
                    m.set(pc.getX() + dx, y, pc.getZ() + dz);
                    BlockState st = mc.world.getBlockState(m);
                    if (st.isAir()) continue;
                    int rgb = rgbOf(st);
                    if (rgb >= 0) BUILD.add(new Found(m.getX(), m.getY(), m.getZ(), rgb));
                }
            }
        }
        layer++;
        if (layer > r * 2) {
            layer = 0;
            final Vec3d pp = mc.player.getPos();
            BUILD.sort((a, b) -> Double.compare(d2(a, pp), d2(b, pp)));
            int max = Math.max(10, Math.round(Config.beMax));
            FOUND.clear();
            FOUND.addAll(BUILD.size() > max ? BUILD.subList(0, max) : BUILD);
            BUILD.clear();
        }
    }

    private static double d2(Found f, Vec3d p) {
        double dx = f.x() + 0.5 - p.x, dy = f.y() + 0.5 - p.y, dz = f.z() + 0.5 - p.z;
        return dx * dx + dy * dy + dz * dz;
    }

    // ------------------------------------------------------------ проекция и рисование

    public static void collect(WorldRenderContext ctx) {
        FRAMES.clear();
        if (!Config.blockEsp || FOUND.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        Vec3d cam = ctx.camera().getPos();
        Matrix4f view = ctx.positionMatrix();
        Matrix4f proj = ctx.projectionMatrix();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        float range = Math.max(4.0f, Config.beRange);

        for (Found f : FOUND) {
            double dx = f.x() + 0.5 - cam.x, dy = f.y() + 0.5 - cam.y, dz = f.z() + 0.5 - cam.z;
            float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            float[] pts = new float[16];
            boolean ok = true;
            for (int i = 0; i < 8 && ok; i++) {
                double cx = f.x() + (i & 1) - cam.x;
                double cy = f.y() + ((i >> 1) & 1) - cam.y;
                double cz = f.z() + ((i >> 2) & 1) - cam.z;
                Vector4f v = new Vector4f((float) cx, (float) cy, (float) cz, 1.0f);
                v.mul(view);
                v.mul(proj);
                if (v.w <= 0.05f) {
                    ok = false;
                    break;
                }
                pts[i * 2] = (v.x / v.w * 0.5f + 0.5f) * sw;
                pts[i * 2 + 1] = (1.0f - (v.y / v.w * 0.5f + 0.5f)) * sh;
            }
            if (!ok) continue;
            float alpha = MathHelper.clamp(1.15f - dist / (range * 1.4f), 0.35f, 1.0f);
            FRAMES.add(new Frame(pts, f.rgb(), alpha));
        }
    }

    public static void draw(DrawContext c, RenderTickCounter tickCounter) {
        if (!Config.blockEsp || FRAMES.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        float px = 1.0f / Ui.scale();
        for (Frame f : FRAMES) {
            int col = Ui.alpha(f.rgb() & 0xFFFFFF, f.alpha());
            for (int[] e : Esp.BOX_EDGES) {
                Esp.tracer(c, f.p()[e[0] * 2], f.p()[e[0] * 2 + 1], f.p()[e[1] * 2], f.p()[e[1] * 2 + 1], col, px * 1.4f);
            }
        }
    }
}
