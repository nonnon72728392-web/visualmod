package dev.voidclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** HUD: watermark, координаты, список модулей, клавиши, Hit Info, броня и счётчики - каждый блок можно двигать. */
public final class Hud {
    private Hud() {}

    public enum Elem { WATERMARK, INFO, MODULES, KEYS, HITINFO, ARMOR, COUNTS, POTIONS }

    public static final int H = 15;      // высота плашки
    private static final int ROW = 16;   // шаг строки в списке модулей
    private static final int KEY = 18, KGAP = 2, SPACE_H = 12;
    private static final int HIT_W = 126, HIT_H = 36;
    private static final int SLOT = 20;  // шаг ячейки брони
    private static final int COUNT_H = 22;
    private static final int BG = 0xB0101018;
    private static final int TEXT = 0xFFEDEDF5;
    private static final int MUTED = 0xFFA0A0B2;
    private static final int RED = 0xFFFF6B6B;
    private static final int GREEN = 0xFF69F0AE;

    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private record ModRow(String name, float v) {}

    private static final Map<String, Float> LIST_ANIM = new HashMap<>();

    // ------------------------------------------------------------ рендер

    public static void render(DrawContext c, RenderTickCounter tickCounter) {
        Anim.frame();
        if (!Config.hud) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        Screen s = mc.currentScreen;
        if (s instanceof HudEditorScreen) return;   // редактор рисует сам

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        if (Config.hudWatermark) draw(c, mc, Elem.WATERMARK, sw, sh, false);
        if (Config.hudInfo) draw(c, mc, Elem.INFO, sw, sh, false);
        if (Config.hudModuleList) draw(c, mc, Elem.MODULES, sw, sh, false);
        if (Config.hudKeys) draw(c, mc, Elem.KEYS, sw, sh, false);
        if (Config.hitInfo && HitInfo.active()) draw(c, mc, Elem.HITINFO, sw, sh, false);
        if (Config.hudArmor) draw(c, mc, Elem.ARMOR, sw, sh, false);
        if (Config.hudCounts && !countItems().isEmpty()) draw(c, mc, Elem.COUNTS, sw, sh, false);
        if (Config.hudPotions && !potionRows(mc, false).isEmpty()) draw(c, mc, Elem.POTIONS, sw, sh, false);
    }

    // ------------------------------------------------------------ геометрия

    private static int listPad() {
        return Config.mlDots ? 22 : 16;
    }

    public static int width(MinecraftClient mc, Elem e, boolean preview) {
        return Math.round(rawWidth(mc, e, preview) * scale());
    }

    public static int height(MinecraftClient mc, Elem e, boolean preview) {
        return Math.round(rawHeight(mc, e, preview) * scale());
    }

    /** Размер всего HUD (настройка Size). */
    public static float scale() {
        return Math.max(0.6f, Math.min(2.0f, Config.hudScale));
    }

    private static int rawWidth(MinecraftClient mc, Elem e, boolean preview) {
        TextRenderer tr = mc.textRenderer;
        switch (e) {
            case WATERMARK: {
                String rest = watermarkRest(mc);
                int w = 9 + Ui.width(tr, "noomi_dlc") + 9;
                if (!rest.isEmpty()) w += 8 + Ui.width(tr, rest);
                return w;
            }
            case INFO:
                return 18 + Ui.width(tr, xyz(mc));
            case KEYS:
                return KEY * 3 + KGAP * 2;
            case HITINFO:
                return HIT_W;
            case POTIONS: {
                int max = 0;
                for (PotRow r : potionRows(mc, preview)) max = Math.max(max, potWidth(tr, r));
                return max;
            }
            case ARMOR:
                return Config.haVertical ? 24 : SLOT * 4 + 10;
            case COUNTS: {
                int cx = 8;
                for (Item it : countItems()) cx += 20 + Ui.width(tr, String.valueOf(count(mc, it, preview))) + 10;
                return cx <= 8 ? 0 : cx - 10 + 8;
            }
            default: {
                int max = 0;
                for (String m : modules(preview)) max = Math.max(max, Ui.width(tr, m) + listPad());
                return max;
            }
        }
    }

    private static int rawHeight(MinecraftClient mc, Elem e, boolean preview) {
        if (e == Elem.MODULES) {
            int n = modules(preview).size();
            return n == 0 ? 0 : n * ROW - 2;
        }
        if (e == Elem.KEYS) return KEY * 2 + KGAP * 2 + (Config.ksSpace ? SPACE_H : 0);
        if (e == Elem.HITINFO) return HIT_H;
        if (e == Elem.POTIONS) {
            int n = potionRows(mc, preview).size();
            return n == 0 ? H : n * ROW - 2;
        }
        if (e == Elem.ARMOR) return Config.haVertical ? SLOT * 4 + 10 : 24;
        if (e == Elem.COUNTS) return COUNT_H;
        return H;
    }

    /** Левый край блока на экране с учётом границ. */
    public static int left(MinecraftClient mc, Elem e, int sw, boolean preview) {
        int w = width(mc, e, preview);
        int x = Config.hudX[e.ordinal()];
        int l = e == Elem.MODULES ? (x < 0 ? sw - 4 : x) - w : x;
        return Math.max(0, Math.min(l, Math.max(0, sw - w)));
    }

    public static int top(MinecraftClient mc, Elem e, int sh, boolean preview) {
        int h = height(mc, e, preview);
        return Math.max(0, Math.min(Config.hudY[e.ordinal()], Math.max(0, sh - h)));
    }

    public static void setPos(MinecraftClient mc, Elem e, int left, int top, boolean preview) {
        int w = width(mc, e, preview);
        Config.hudX[e.ordinal()] = e == Elem.MODULES ? left + w : left;
        Config.hudY[e.ordinal()] = top;
    }

    // ------------------------------------------------------------ содержимое

    private static String watermarkRest(MinecraftClient mc) {
        String rest = "";
        if (Config.hudFps) rest = mc.getCurrentFps() + " fps";
        if (Config.hudPing) {
            int ping = ping(mc);
            if (ping >= 0) rest += (rest.isEmpty() ? "" : "  |  ") + ping + " ms";
        }
        if (Config.hudTime) {
            rest += (rest.isEmpty() ? "" : "  |  ") + java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
        }
        return rest;
    }

    private static String xyz(MinecraftClient mc) {
        if (mc.player == null) return "XYZ  0  0  0";
        String s = String.format("XYZ  %d  %d  %d",
                (int) Math.floor(mc.player.getX()),
                (int) Math.floor(mc.player.getY()),
                (int) Math.floor(mc.player.getZ()));
        if (Config.hudFacing) {
            String f = mc.player.getHorizontalFacing().asString();
            if (!f.isEmpty()) s += "  " + f.substring(0, 1).toUpperCase();
        }
        return s;
    }

    public static List<String> modules(boolean preview) {
        List<String> mods = new ArrayList<>();
        if (preview || Config.esp) mods.add("ESP");
        if (preview || Config.seeInvisibles) mods.add("SeeInvisibles");
        if (preview || Config.fullbright) mods.add("Fullbright");
        if (preview || Config.nameTags) mods.add("NameTags");
        if (preview || Config.itemPhysics) mods.add("ItemPhysics");
        if (preview || Config.jumpCircle) mods.add("JumpCircle");
        if (preview || Config.chinaHat) mods.add("ChinaHat");
        if (preview || Config.noParticles) mods.add("NoParticles");
        if (preview || Config.noHurtCam) mods.add("NoHurtCam");
        if (preview || Config.noFire) mods.add("NoFire");
        if (preview || Config.zoom) mods.add("Zoom");
        if (preview || Config.viewModel) mods.add("ViewModel");
        if (preview || Config.swingAnim) mods.add("Swing");
        if (preview || Config.hitInfo) mods.add("HitInfo");
        if (preview || Config.killAura) mods.add("KillAura");
        if (preview || Config.legitAura) mods.add("LegitAura");
        if (preview || Config.fxParticles) mods.add("Particles");
        if (preview || Config.triggerBot) mods.add("TriggerBot");
        if (preview || Config.autoTotem) mods.add("AutoTotem");
        if (preview || Config.clickPearl) mods.add("ClickPearl");
        if (preview || Config.clickWind) mods.add("ClickWind");
        if (preview || Config.invMove) mods.add("InvMove");
        if (preview || Config.blockEsp) mods.add("BlockESP");
        if (preview || Config.blockFx) mods.add("BlockFx");
        if (preview || Config.fly) mods.add("Fly");
        if (preview || Config.spider) mods.add("Spider");
        if (preview || Config.noWeb) mods.add("NoWeb");
        if (preview || Config.airSwim) mods.add("AirSwim");
        if (preview || Config.airStuck) mods.add("AirStuck");
        if (preview || Config.sky) mods.add("CustomSky");
        if (preview || Config.stretch) mods.add("Stretch");
        if (preview || Config.ambient) mods.add("Ambient");
        if (preview || Config.cinematic) mods.add("Cinematic");
        if (preview || Config.reach) mods.add("Reach");
        if (preview || Config.noFall) mods.add("NoFall");
        if (preview || Config.jesus) mods.add("Jesus");
        if (preview || Config.antiAfk) mods.add("AntiAFK");
        if (preview || Config.noClip) mods.add("NoClip");
        if (preview || Config.autoSprint) mods.add("AutoSprint");
        if (preview || Config.autoRespawn) mods.add("AutoRespawn");
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        mods.sort(Comparator.comparingInt((String a) -> Ui.width(tr, a)).reversed());
        return mods;
    }

    /** Список с плавным появлением/исчезновением строк. */
    private static List<ModRow> animatedModules() {
        Set<String> active = new HashSet<>(modules(false));
        List<ModRow> out = new ArrayList<>();
        for (String n : modules(true)) {
            float cur = LIST_ANIM.getOrDefault(n, 0.0f);
            cur = Anim.step(cur, active.contains(n) ? 1.0f : 0.0f, 14.0f);
            LIST_ANIM.put(n, cur);
            if (cur > 0.02f) out.add(new ModRow(n, cur));
        }
        return out;
    }

    private static List<ModRow> previewModules() {
        List<ModRow> out = new ArrayList<>();
        for (String n : modules(true)) out.add(new ModRow(n, 1.0f));
        return out;
    }

    // ------------------------------------------------------------ предметы

    private static List<Item> countItems() {
        List<Item> l = new ArrayList<>();
        if (Config.ctTotem) l.add(Items.TOTEM_OF_UNDYING);
        if (Config.ctPearl) l.add(Items.ENDER_PEARL);
        if (Config.ctWind) l.add(Items.WIND_CHARGE);
        return l;
    }

    private static int count(MinecraftClient mc, Item item, boolean preview) {
        if (preview) return item == Items.TOTEM_OF_UNDYING ? 3 : item == Items.ENDER_PEARL ? 16 : 8;
        if (mc.player == null) return 0;
        PlayerInventory inv = mc.player.getInventory();
        int n = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack st = inv.getStack(i);
            if (st.isOf(item)) n += st.getCount();
        }
        return n;
    }

    private static ItemStack armorStack(MinecraftClient mc, int i, boolean preview) {
        if (preview) {
            Item[] it = {Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS};
            ItemStack st = new ItemStack(it[i]);
            st.setDamage(st.getMaxDamage() / 4 * (i + 1) / 2);
            return st;
        }
        return mc.player == null ? ItemStack.EMPTY : mc.player.getEquippedStack(ARMOR_SLOTS[i]);
    }

    // ------------------------------------------------------------ рисование блока

    public static void draw(DrawContext c, MinecraftClient mc, Elem e, int sw, int sh, boolean preview) {
        float sc = scale();
        int x = left(mc, e, sw, preview);
        int y = top(mc, e, sh, preview);
        int w = rawWidth(mc, e, preview);
        if (Math.abs(sc - 1.0f) < 0.001f) {
            drawRaw(c, mc, e, x, y, w, preview);
            return;
        }
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(x, y, 0.0f);
        m.scale(sc, sc, 1.0f);
        drawRaw(c, mc, e, 0, 0, w, preview);
        m.pop();
    }

    private static void drawRaw(DrawContext c, MinecraftClient mc, Elem e, int x, int y, int w, boolean preview) {
        TextRenderer tr = mc.textRenderer;
        int accent = Config.accent();

        switch (e) {
            case WATERMARK: {
                Ui.shadow(c, x, y, w, H, 7);
                Ui.capsule(c, x, y, w, H, BG);
                {   // бегущая градиентная линия под ватермарком
                    int segs = 14;
                    float sw2 = (w - 16) / (float) segs;
                    for (int i = 0; i < segs; i++) {
                        Ui.rect(c, x + 8 + i * sw2, y + H - 2, x + 8 + (i + 1) * sw2 + 0.5f, y + H - 0.5f,
                                Ui.alpha(Config.flow(i / (float) segs * 0.6f) & 0xFFFFFF, 0.95f));
                    }
                }
                int tx = x + 9;
                gradText(c, tr, "noomi_dlc", tx, y, H, accent, accent2());
                tx += Ui.width(tr, "noomi_dlc");
                String rest = watermarkRest(mc);
                if (!rest.isEmpty()) Ui.textMid(c, tr, rest, tx + 8, y, H, MUTED);
                break;
            }
            case INFO: {
                Ui.shadow(c, x, y, w, H, 7);
                Ui.capsule(c, x, y, w, H, BG);
                Ui.capsuleF(c, x + 4.5f, y + (H - 8) / 2.0f, 8, 8, Ui.alpha(accent, 0.25f));
                Ui.capsule(c, x + 6, y + (H - 5) / 2, 5, 5, accent);
                Ui.textMid(c, tr, xyz(mc), x + 15, y, H, MUTED);
                break;
            }
            case KEYS: {
                key(c, mc, "W", mc.options.forwardKey.isPressed(), x + KEY + KGAP, y, KEY, KEY, accent);
                key(c, mc, "A", mc.options.leftKey.isPressed(), x, y + KEY + KGAP, KEY, KEY, accent);
                key(c, mc, "S", mc.options.backKey.isPressed(), x + KEY + KGAP, y + KEY + KGAP, KEY, KEY, accent);
                key(c, mc, "D", mc.options.rightKey.isPressed(), x + (KEY + KGAP) * 2, y + KEY + KGAP, KEY, KEY, accent);
                if (Config.ksSpace) {
                    key(c, mc, "", mc.options.jumpKey.isPressed(), x, y + (KEY + KGAP) * 2, w, SPACE_H, accent);
                }
                break;
            }
            case HITINFO:
                drawHit(c, tr, x, y, w, preview, accent);
                break;
            case ARMOR:
                drawArmor(c, mc, x, y, w, rawHeight(mc, e, preview), preview);
                break;
            case COUNTS:
                drawCounts(c, mc, x, y, w, preview);
                break;
            case POTIONS:
                drawPotions(c, mc, x, y, w, preview);
                break;
            default: {
                int right = x + w;
                float ry = y;
                int pad = listPad();
                List<ModRow> rowsL = preview ? previewModules() : animatedModules();
                int idx = 0;
                int cnt = Math.max(1, rowsL.size() - 1);
                int acc2 = accent2();
                for (ModRow r : rowsL) {
                    int rc = Ui.mix(accent, acc2, idx / (float) cnt);
                    idx++;
                    float ez = Anim.ease(r.v());
                    int rw = Ui.width(tr, r.name()) + pad;
                    int rh = ROW - 2;
                    float rx = right - rw + (1.0f - ez) * (rw + 6);
                    Ui.capsuleF(c, rx, ry, rw, rh, BG);
                    Ui.rrectF(c, rx + rw - 3.0f, ry + 2.5f, 2.0f, rh - 5.0f, 1.0f, rc);
                    float tx = rx + 9;
                    if (Config.mlDots) {
                        Ui.capsuleF(c, rx + 5.5f, ry + (rh - 7) / 2.0f, 7, 7, Ui.alpha(rc, 0.22f));
                        Ui.capsuleF(c, rx + 7, ry + (rh - 4) / 2.0f, 4, 4, rc);
                        tx = rx + 15;
                    }
                    Ui.textMidF(c, tr, r.name(), tx, ry, rh, Ui.mix(TEXT, rc, 0.22f));
                    ry += ROW * ez;
                }
            }
        }
    }


    // ------------------------------------------------------------ зелья (эффекты)

    public record PotRow(String name, String time, int color, boolean low) {}

    private static final String[] ROMAN = {"", "", " II", " III", " IV", " V", " VI", " VII", " VIII", " IX", " X"};

    public static String effName(StatusEffectInstance in) {
        String n = in.getEffectType().value().getName().getString();
        int a = in.getAmplifier();
        if (a >= 1) n += a < ROMAN.length ? ROMAN[a] : " " + (a + 1);
        return n;
    }

    public static String effTime(StatusEffectInstance in) {
        if (in.isInfinite()) return "inf";
        int s = Math.max(0, in.getDuration() / 20);
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    public static int effColor(StatusEffectInstance in) {
        return 0xFF000000 | in.getEffectType().value().getColor();
    }

    public static boolean effLow(StatusEffectInstance in) {
        return !in.isInfinite() && in.getDuration() < 200;
    }

    public static List<PotRow> potionRows(MinecraftClient mc, boolean preview) {
        List<PotRow> out = new ArrayList<>();
        if (preview) {
            out.add(new PotRow("Speed II", "3:20", 0xFF7CAFC6, false));
            out.add(new PotRow("Strength", "1:05", 0xFF932423, false));
            out.add(new PotRow("Regeneration", "0:08", 0xFFCD5CAB, true));
            return out;
        }
        if (mc.player == null) return out;
        for (StatusEffectInstance in : mc.player.getStatusEffects()) {
            if (Config.fullbright && in.getEffectType() == StatusEffects.NIGHT_VISION && !in.shouldShowParticles()) continue;
            out.add(new PotRow(effName(in), effTime(in), effColor(in), effLow(in)));
        }
        out.sort(Comparator.comparing(PotRow::name));
        return out;
    }

    private static int potWidth(TextRenderer tr, PotRow r) {
        int w = 8 + 8 + Ui.width(tr, r.name()) + 8;
        if (Config.hpTimer) w += Ui.width(tr, r.time()) + 8;
        return w + 4;
    }

    private static void drawPotions(DrawContext c, MinecraftClient mc, int x, int y, int w, boolean preview) {
        TextRenderer tr = mc.textRenderer;
        float ry = y;
        for (PotRow r : potionRows(mc, preview)) {
            int rh = ROW - 2;
            Ui.capsule(c, x, (int) ry, w, rh, BG);
            Ui.capsuleF(c, x + 7, ry + (rh - 5) / 2.0f, 5, 5, r.color());
            Ui.textMid(c, tr, r.name(), x + 16, (int) ry, rh, TEXT);
            if (Config.hpTimer) {
                Ui.textMid(c, tr, r.time(), x + w - 9 - Ui.width(tr, r.time()), (int) ry, rh, r.low() ? RED : MUTED);
            }
            ry += ROW;
        }
    }

    private static void drawArmor(DrawContext c, MinecraftClient mc, int x, int y, int w, int h, boolean preview) {
        boolean vert = Config.haVertical;
        Ui.rrect(c, x, y, w, h, 10, BG);
        for (int i = 0; i < 4; i++) {
            int ix = vert ? x + 4 : x + 5 + i * SLOT + 2;
            int iy = vert ? y + 5 + i * SLOT : y + 2;
            ItemStack st = armorStack(mc, i, preview);
            if (st.isEmpty()) {
                Ui.capsuleF(c, ix + 6.0f, iy + 6.0f, 4, 4, 0x40FFFFFF);
                continue;
            }
            c.drawItem(st, ix, iy);
            if (Config.haDurability && st.isDamageable()) {
                float frac = MathHelper.clamp(1.0f - (float) st.getDamage() / Math.max(1, st.getMaxDamage()), 0.0f, 1.0f);
                int col = 0xFF000000 | MathHelper.hsvToRgb(frac * 0.33f, 0.75f, 1.0f);
                float bx = ix + 1.0f, by = iy + 17.0f;
                Ui.rrectF(c, bx, by, 14, 2, 1, 0x80000000);
                Ui.rrectF(c, bx, by, Math.max(1.5f, 14 * frac), 2, 1, col);
            }
        }
    }

    private static void drawCounts(DrawContext c, MinecraftClient mc, int x, int y, int w, boolean preview) {
        if (w <= 0) return;
        TextRenderer tr = mc.textRenderer;
        Ui.capsule(c, x, y, w, COUNT_H, BG);
        int cx = x + 8;
        for (Item it : countItems()) {
            int n = count(mc, it, preview);
            String s = String.valueOf(n);
            c.drawItem(new ItemStack(it), cx, y + 3);
            Ui.textMid(c, tr, s, cx + 20, y, COUNT_H, n > 0 ? TEXT : MUTED);
            cx += 20 + Ui.width(tr, s) + 10;
        }
    }

    private static void drawHit(DrawContext c, TextRenderer tr, int x, int y, int w, boolean preview, int accent) {
        String name = preview ? "Player" : HitInfo.name();
        float hp = preview ? 14.0f : HitInfo.hp;
        float max = preview ? 20.0f : HitInfo.maxHp;
        float dealt = preview ? 12.5f : HitInfo.dealt;
        float healed = preview ? 4.0f : HitInfo.healed;
        float last = preview ? 3.5f : HitInfo.lastHit;

        Ui.shadow(c, x, y, w, HIT_H, 9);
        Ui.rrect(c, x, y, w, HIT_H, 9, BG);

        if (Config.hiName) Ui.textMid(c, tr, name, x + 10, y + 2, 14, accent);
        String hpText = String.format("%.1f", hp);
        Ui.textMid(c, tr, hpText, x + w - 10 - Ui.width(tr, hpText), y + 2, 14, TEXT);

        String d = "-" + String.format("%.1f", dealt);
        Ui.textMid(c, tr, d, x + 10, y + 15, 14, RED);
        if (Config.hiLast && last > 0.0f) {
            String l = "(" + String.format("%.1f", last) + ")";
            Ui.textMid(c, tr, l, x + 14 + Ui.width(tr, d), y + 15, 14, MUTED);
        }
        if (Config.hiHealed) {
            String h = "+" + String.format("%.1f", healed);
            Ui.textMid(c, tr, h, x + w - 10 - Ui.width(tr, h), y + 15, 14, GREEN);
        }

        if (Config.hiBar) {
            float frac = MathHelper.clamp(hp / Math.max(1.0f, max), 0.0f, 1.0f);
            int bw = w - 20;
            int hpColor = 0xFF000000 | MathHelper.hsvToRgb(frac * 0.33f, 0.75f, 1.0f);
            Ui.rrectF(c, x + 10, y + HIT_H - 6, bw, 3, 1.5f, 0x80000000);
            Ui.rrectF(c, x + 10, y + HIT_H - 6, Math.max(3.0f, bw * frac), 3, 1.5f, hpColor);
        }
    }

    private static void key(DrawContext c, MinecraftClient mc, String label, boolean down,
                            int x, int y, int w, int h, int accent) {
        if (down) Ui.rrect(c, x - 2, y - 2, w + 4, h + 4, h / 2 + 2, Ui.alpha(accent, 0.28f));
        Ui.rrect(c, x, y, w, h, h / 2, down ? accent : BG);
        if (label.isEmpty()) {
            Ui.capsule(c, x + w / 2 - 8, y + h / 2 - 1, 16, 2, down ? 0xFFFFFFFF : MUTED);
        } else {
            int tw = Ui.width(mc.textRenderer, label);
            Ui.textMid(c, mc.textRenderer, label, x + (w - tw) / 2, y, h, down ? 0xFFFFFFFF : MUTED);
        }
    }

    /** Второй цвет темы: тот же акцент, сдвинутый по оттенку (для градиентов). */
    public static int accent2() {
        if (Config.isFlow()) return Config.flow(0.22f);
        int a = Config.accent();
        float r = ((a >> 16) & 255) / 255.0f, g = ((a >> 8) & 255) / 255.0f, b = (a & 255) / 255.0f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        float h;
        if (d == 0.0f) h = 0.0f;
        else if (max == r) h = ((g - b) / d) % 6.0f;
        else if (max == g) h = (b - r) / d + 2.0f;
        else h = (r - g) / d + 4.0f;
        h /= 6.0f;
        if (h < 0.0f) h += 1.0f;
        float s = max == 0.0f ? 0.0f : d / max;
        return 0xFF000000 | MathHelper.hsvToRgb((h + 0.14f) % 1.0f, s, max);
    }

    /** Текст с плавным градиентом от c1 к c2 и бегущей волной. */
    private static int gradText(DrawContext c, TextRenderer tr, String s, int x, int y, int h, int c1, int c2) {
        long now = System.currentTimeMillis();
        int cx = x;
        for (int i = 0; i < s.length(); i++) {
            float k = s.length() <= 1 ? 0.0f : i / (float) (s.length() - 1);
            float wave = 0.5f + 0.5f * (float) Math.sin(now / 450.0 - i * 0.55);
            Ui.textMid(c, tr, s.substring(i, i + 1), cx, y, h, Ui.mix(Ui.mix(c1, c2, k), 0xFFFFFFFF, wave * 0.35f));
            cx += Ui.width(tr, s.substring(0, i + 1)) - Ui.width(tr, s.substring(0, i));
        }
        return cx;
    }

    private static int ping(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null || mc.player == null) return -1;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return e == null ? -1 : e.getLatency();
    }
}
