package dev.voidclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Прикольные штуки для экрана: хит-маркер, комбо, неоновая рамка экрана, красная пульсация при низком HP. */
public final class Extras {
    private Extras() {}

    private static long lastHit = 0L;
    private static int combo = 0;

    /** Вызывается при каждом ударе по сущности (в том числе от аур). */
    public static void hit() {
        long now = System.currentTimeMillis();
        combo = (now - lastHit < 3000L) ? combo + 1 : 1;
        lastHit = now;
    }

    private static int argb(int rgb, float a) {
        int al = Math.max(0, Math.min(255, Math.round(a * 255.0f)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    public static void draw(DrawContext c, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        long now = System.currentTimeMillis();

        if (Config.exLowHp) lowHp(c, mc, w, h, now);
        if (Config.exBorder) border(c, w, h, now);
        if (mc.currentScreen == null) {
            if (Config.exHitMarker) hitMarker(c, w, h, now);
            if (Config.exCombo) combo(c, mc, w, h, now);
        }
    }

    private static void hitMarker(DrawContext c, int w, int h, long now) {
        float age = (now - lastHit) / 380.0f;
        if (lastHit == 0L || age >= 1.0f) return;
        float a = 1.0f - age;
        float gap = 4.0f + age * 4.0f;
        float len = 5.0f;
        int col = argb(Config.accent() & 0xFFFFFF, a);
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(w / 2.0f, h / 2.0f, 0.0f);
        for (int i = 0; i < 4; i++) {
            m.push();
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(45.0f + 90.0f * i));
            Ui.rect(c, gap, -0.7f, gap + len, 0.7f, col);
            m.pop();
        }
        m.pop();
    }

    private static void combo(DrawContext c, MinecraftClient mc, int w, int h, long now) {
        long age = now - lastHit;
        if (lastHit == 0L || age > 3000L || combo < 2) return;
        float a = age > 2400L ? 1.0f - (age - 2400L) / 600.0f : 1.0f;
        String s = "COMBO x" + combo;
        int tw = Ui.width(mc.textRenderer, s);
        float x = w / 2.0f - tw / 2.0f;
        float y = h / 2.0f + 14.0f;
        Ui.rrectF(c, x - 7, y - 2, tw + 14, 13, 6.5f, argb(0x0C0C14, 0.65f * a));
        Ui.rect(c, x - 3, y + 10.5f, x + tw + 3, y + 11.5f, argb(Config.flow(0.1f) & 0xFFFFFF, 0.9f * a));
        Ui.textMidF(c, mc.textRenderer, s, x, y - 2, 13, argb(0xFFFFFF, a));
    }

    /** Неоновая рамка по краям экрана: цвет бежит по периметру в тон выбранной темы. */
    private static void border(DrawContext c, int w, int h, long now) {
        int seg = 20;
        int depth = Math.max(3, Math.round(8.0f * Config.exBorderSize));
        float per = 2.0f * (w + h);
        for (int j = 0; j < seg; j++) {
            float f0 = (float) j / seg, f1 = (float) (j + 1) / seg;
            int xa = Math.round(f0 * w), xb = Math.round(f1 * w);
            int ya = Math.round(f0 * h), yb = Math.round(f1 * h);
            int top = Config.isFlow() ? Config.flow((j + 0.5f) / seg * (w / per)) : Config.accent();
            int right = Config.isFlow() ? Config.flow((w + (j + 0.5f) / seg * h) / per) : Config.accent();
            int bottom = Config.isFlow() ? Config.flow((w + h + (1.0f - (j + 0.5f) / seg) * w) / per) : Config.accent();
            int left = Config.isFlow() ? Config.flow((2 * w + h + (1.0f - (j + 0.5f) / seg) * h) / per) : Config.accent();
            for (int d = 0; d < depth; d++) {
                float k = 1.0f - d / (float) depth;
                float a = 0.55f * k * k;
                c.fill(xa, d, xb, d + 1, argb(top, a));
                c.fill(xa, h - d - 1, xb, h - d, argb(bottom, a));
                c.fill(w - d - 1, ya, w - d, yb, argb(right, a));
                c.fill(d, ya, d + 1, yb, argb(left, a));
            }
        }
    }

    /** Красная пульсация по краям, когда осталось мало здоровья. */
    private static void lowHp(DrawContext c, MinecraftClient mc, int w, int h, long now) {
        float hp = mc.player.getHealth();
        if (hp > 6.0f || !mc.player.isAlive()) return;
        float need = MathHelper.clamp((6.0f - hp) / 6.0f, 0.0f, 1.0f);
        float pulse = 0.5f + 0.5f * (float) Math.sin(now / (260.0 - 120.0 * need));
        int steps = 14;
        for (int i = 0; i < steps; i++) {
            float k = 1.0f - i / (float) steps;
            int col = argb(0xFF1E2A, (0.10f + 0.22f * need) * (0.5f + 0.5f * pulse) * k * k);
            c.fill(0, i, w, i + 1, col);
            c.fill(0, h - i - 1, w, h - i, col);
            c.fill(i, 0, i + 1, h, col);
            c.fill(w - i - 1, 0, w - i, h, col);
        }
    }
}
