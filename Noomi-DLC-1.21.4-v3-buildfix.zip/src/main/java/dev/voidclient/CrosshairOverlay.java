package dev.voidclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

/** Настраиваемый клиентский прицел. Не меняет механику попаданий. */
public final class CrosshairOverlay {
    private CrosshairOverlay() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.customCrosshair || mc.player == null || mc.options.hudHidden
                || mc.currentScreen != null || mc.player.isSpectator()) return;

        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        float size = MathHelper.clamp(Config.crosshairSize, 2.0f, 14.0f);
        float gap = MathHelper.clamp(Config.crosshairGap, 0.0f, 10.0f);
        float thick = MathHelper.clamp(Config.crosshairThickness, 1.0f, 4.0f);
        if (Config.crosshairDynamic && mc.player.isSprinting()) gap += 1.5f;

        int color = Config.accent() | 0xFF000000;
        int shadow = 0xAA000000;
        int style = MathHelper.clamp(Config.crosshairStyle, 0, 3);

        if (style == 1) {
            rect(ctx, cx, cy, thick + 2, thick + 2, shadow);
            rect(ctx, cx, cy, thick, thick, color);
            return;
        }

        if (style == 0 || style == 2 || style == 3) {
            // Four segments; style 3 omits the upper segment (T-shape).
            rect(ctx, cx, cy - gap - size / 2, thick + 2, size + 2, shadow);
            rect(ctx, cx, cy + gap + size / 2, thick + 2, size + 2, shadow);
            rect(ctx, cx - gap - size / 2, cy, size + 2, thick + 2, shadow);
            if (style != 3) rect(ctx, cx, cy - gap - size / 2, thick, size, color);
            rect(ctx, cx, cy + gap + size / 2, thick, size, color);
            rect(ctx, cx - gap - size / 2, cy, size, thick, color);
            rect(ctx, cx + gap + size / 2, cy, size, thick, color);
        }
    }

    private static void rect(DrawContext ctx, float cx, float cy, float w, float h, int color) {
        int iw = Math.max(1, Math.round(w));
        int ih = Math.max(1, Math.round(h));
        int left = Math.round(cx - iw / 2.0f);
        int top = Math.round(cy - ih / 2.0f);
        ctx.fill(left, top, left + iw, top + ih, color);
    }
}
