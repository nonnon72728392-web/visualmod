package dev.voidclient.mixin;

import dev.voidclient.ItemStateExt;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/** Запоминает, лежит ли предмет на земле (для Item Physics). */
@Mixin(ItemEntityRenderState.class)
public class ItemEntityRenderStateMixin implements ItemStateExt {
    @Unique
    private boolean noomi_dlc$onGround;

    @Override
    public boolean noomi_dlc$isOnGround() {
        return noomi_dlc$onGround;
    }

    @Override
    public void noomi_dlc$setOnGround(boolean onGround) {
        this.noomi_dlc$onGround = onGround;
    }
}
