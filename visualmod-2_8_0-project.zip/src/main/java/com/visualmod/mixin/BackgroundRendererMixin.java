package com.visualmod.mixin;

import com.visualmod.Config;
import com.visualmod.Sky;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Custom Sky: туман у горизонта в цвет неба (под водой и в лаве не трогаем). */
@Mixin(BackgroundRenderer.class)
public abstract class BackgroundRendererMixin {
    @Inject(method = "getFogColor(Lnet/minecraft/client/render/Camera;FLnet/minecraft/client/world/ClientWorld;IF)Lorg/joml/Vector4f;",
            at = @At("RETURN"), cancellable = true, require = 0)
    private static void visualmod$fog(Camera camera, float tickDelta, ClientWorld world, int viewDistance, float skyDarkness,
                                      CallbackInfoReturnable<Vector4f> cir) {
        if (!Sky.colorOn() || !Config.skyFog) return;
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null || p.isSubmergedInWater() || p.isInLava()) return;
        int rgb = Sky.rgb();
        Vector4f v = cir.getReturnValue();
        v.set(((rgb >> 16) & 255) / 255.0f, ((rgb >> 8) & 255) / 255.0f, (rgb & 255) / 255.0f, v.w);
        cir.setReturnValue(v);
    }
}
