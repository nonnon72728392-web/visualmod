package com.visualmod.mixin;

import com.visualmod.Config;
import com.visualmod.Sky;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Custom Sky: цвет неба и облаков. Дескрипторы указаны полностью - если в вашей версии они другие, инжект просто пропустится. */
@Mixin(ClientWorld.class)
public abstract class ClientWorldMixin {
    @Inject(method = "getSkyColor(Lnet/minecraft/util/math/Vec3d;F)I", at = @At("RETURN"), cancellable = true, require = 0)
    private void visualmod$sky(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Integer> cir) {
        if (Sky.colorOn()) cir.setReturnValue(0xFF000000 | Sky.rgb());
    }

    @Inject(method = "getCloudsColor(F)I", at = @At("RETURN"), cancellable = true, require = 0)
    private void visualmod$clouds(float tickDelta, CallbackInfoReturnable<Integer> cir) {
        if (Sky.colorOn() && Config.skyClouds) cir.setReturnValue(0xFF000000 | Sky.scale(Sky.rgb(), 1.12f));
    }
}
