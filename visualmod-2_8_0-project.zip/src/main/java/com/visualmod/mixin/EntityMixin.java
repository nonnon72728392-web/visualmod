package com.visualmod.mixin;

import com.visualmod.Config;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** No Web: паутина не замедляет игрока. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "slowMovement", at = @At("HEAD"), cancellable = true, require = 0)
    private void visualmod$noWeb(BlockState state, Vec3d multiplier, CallbackInfo ci) {
        if (Config.noWeb && (Object) this instanceof ClientPlayerEntity && state.isOf(Blocks.COBWEB)) {
            ci.cancel();
        }
    }
}
