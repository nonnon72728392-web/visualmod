package com.visualmod.mixin;

import com.visualmod.Sky;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Custom Sky: своё время суток на клиенте (небо, солнце, звёзды). */
@Mixin(World.class)
public abstract class WorldMixin {
    @Inject(method = "getTimeOfDay()J", at = @At("RETURN"), cancellable = true, require = 0)
    private void visualmod$time(CallbackInfoReturnable<Long> cir) {
        if ((Object) this instanceof ClientWorld) cir.setReturnValue(Sky.time(cir.getReturnValueJ()));
    }

    @Inject(method = "getLunarTime()J", at = @At("RETURN"), cancellable = true, require = 0)
    private void visualmod$lunar(CallbackInfoReturnable<Long> cir) {
        if ((Object) this instanceof ClientWorld) cir.setReturnValue(Sky.time(cir.getReturnValueJ()));
    }
}
