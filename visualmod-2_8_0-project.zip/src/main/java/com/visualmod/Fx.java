package com.visualmod;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Particles: собственные светящиеся частицы (не ванильные, поэтому работают и вместе с No Particles).
 * Hit burst - вспышка при ударе по существу, Orbit - частицы кружат вокруг игрока, Trail - шлейф из-под ног.
 */
public final class Fx {
    private Fx() {}

    private static final class P {
        float x, y, z, vx, vy, vz, size, hue, drag, gravity;
        int life, max;
    }

    private static final List<P> LIST = new ArrayList<>();
    private static final Map<UUID, Integer> HURT = new HashMap<>();
    private static final Random R = new Random();
    private static int n = 0;

    private static boolean burstOn() { return Config.fxMode == 0 || Config.fxMode == 3; }
    private static boolean orbitOn() { return Config.fxMode == 1 || Config.fxMode == 3; }
    private static boolean trailOn() { return Config.fxMode == 2 || Config.fxMode == 3; }

    // ------------------------------------------------------------ спавн

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null || !Config.fxParticles) {
            LIST.clear();
            HURT.clear();
            return;
        }
        n++;
        if (HURT.size() > 512) HURT.clear();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e instanceof ArmorStandEntity) continue;
            int prev = HURT.getOrDefault(e.getUuid(), 0);
            if (burstOn() && le != mc.player && le.hurtTime > prev && le.squaredDistanceTo(mc.player) < 400.0) {
                burst(le);
            }
            HURT.put(e.getUuid(), le.hurtTime);
        }

        boolean firstPerson = mc.options.getPerspective().isFirstPerson();
        for (PlayerEntity p : mc.world.getPlayers()) {
            boolean self = p == mc.player;
            if (!self && !Config.fxOthers) continue;
            if (self && firstPerson && !trailOn()) continue;
            if (!p.isAlive() || p.isInvisible() || p.isSpectator()) continue;
            if (orbitOn() && !(self && firstPerson)) orbit(p);
            if (trailOn()) trail(p);
        }

        for (int i = LIST.size() - 1; i >= 0; i--) {
            P q = LIST.get(i);
            if (++q.life >= q.max) {
                LIST.remove(i);
                continue;
            }
            q.x += q.vx;
            q.y += q.vy;
            q.z += q.vz;
            q.vx *= q.drag;
            q.vy = q.vy * q.drag - q.gravity;
            q.vz *= q.drag;
        }
        if (LIST.size() > 2500) LIST.subList(0, LIST.size() - 2500).clear();
    }

    private static P make(double x, double y, double z, int max, float size) {
        P q = new P();
        q.x = (float) x;
        q.y = (float) y;
        q.z = (float) z;
        q.max = max;
        q.size = size * Config.fxSize;
        q.hue = R.nextFloat();
        q.drag = 0.93f;
        q.gravity = 0.0f;
        LIST.add(q);
        return q;
    }

    private static void burst(LivingEntity e) {
        int count = Math.max(4, Math.round(22 * Config.fxAmount));
        double cy = e.getY() + e.getHeight() * 0.55;
        for (int i = 0; i < count; i++) {
            P q = make(e.getX(), cy, e.getZ(), 16 + R.nextInt(14), 0.07f + R.nextFloat() * 0.06f);
            double a = R.nextDouble() * Math.PI * 2.0;
            double up = R.nextDouble() * 2.0 - 0.7;
            double sp = 0.07 + R.nextDouble() * 0.13;
            double flat = Math.sqrt(Math.max(0.0, 1.0 - up * up * 0.5));
            q.vx = (float) (Math.cos(a) * sp * flat);
            q.vz = (float) (Math.sin(a) * sp * flat);
            q.vy = (float) (up * sp * 0.8);
            q.gravity = 0.004f;
            q.drag = 0.9f;
        }
    }

    private static void orbit(PlayerEntity p) {
        int per = Math.max(1, Math.round(2 * Config.fxAmount));
        for (int i = 0; i < per; i++) {
            double ang = n * 0.16 + i * Math.PI * 2.0 / per;
            double r = 0.75;
            double y = p.getY() + (Math.sin(n * 0.06 + i) * 0.5 + 0.5) * p.getHeight();
            P q = make(p.getX() + Math.cos(ang) * r, y, p.getZ() + Math.sin(ang) * r, 16 + R.nextInt(8), 0.06f);
            q.vx = (float) (-Math.sin(ang) * 0.035);
            q.vz = (float) (Math.cos(ang) * 0.035);
            q.vy = 0.006f;
            q.drag = 0.97f;
            q.hue = (float) ((ang / (Math.PI * 2.0)) % 1.0);
        }
    }

    private static void trail(PlayerEntity p) {
        double dx = p.getX() - p.prevX, dz = p.getZ() - p.prevZ;
        if (dx * dx + dz * dz < 0.0025) return;
        int per = Math.max(1, Math.round(2 * Config.fxAmount));
        for (int i = 0; i < per; i++) {
            P q = make(p.getX() + (R.nextDouble() - 0.5) * 0.4, p.getY() + 0.05 + R.nextDouble() * 0.25,
                    p.getZ() + (R.nextDouble() - 0.5) * 0.4, 18 + R.nextInt(10), 0.07f + R.nextFloat() * 0.04f);
            q.vx = (R.nextFloat() - 0.5f) * 0.01f;
            q.vz = (R.nextFloat() - 0.5f) * 0.01f;
            q.vy = 0.012f + R.nextFloat() * 0.02f;
            q.drag = 0.96f;
        }
    }

    // ------------------------------------------------------------ рендер

    public static void render(WorldRenderContext ctx) {
        if (!Config.fxParticles || LIST.isEmpty()) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(true);
        Quaternionf rot = ctx.camera().getRotation();
        Vector3f right = new Vector3f(1.0f, 0.0f, 0.0f).rotate(rot);
        Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f).rotate(rot);

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f mat = ms.peek().getPositionMatrix();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SrcFactor.SRC_ALPHA,
                com.mojang.blaze3d.platform.GlStateManager.DstFactor.ONE);   // сложение света - светящиеся частицы
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (P q : LIST) {
            float f = (q.life + td) / q.max;
            float fade = (float) Math.pow(1.0f - Math.min(1.0f, f), 1.3);
            float x = q.x + q.vx * td, y = q.y + q.vy * td, z = q.z + q.vz * td;
            int rgb = WorldFx.rgbOf(Config.fxColor, q.hue);

            quad(b, mat, x, y, z, right, up, q.size * 2.6f * (0.6f + 0.4f * fade), rgb, fade * 0.22f);   // ореол
            quad(b, mat, x, y, z, right, up, q.size * (0.5f + 0.5f * fade), rgb | 0, Math.min(1.0f, fade * 1.1f)); // ядро
        }
        BufferRenderer.drawWithGlobalProgram(b.end());

        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ms.pop();
    }

    private static void quad(BufferBuilder b, Matrix4f m, float x, float y, float z,
                             Vector3f r, Vector3f u, float s, int rgb, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255.0f)));
        int col = (a << 24) | (rgb & 0xFFFFFF);
        b.vertex(m, x + (-r.x - u.x) * s, y + (-r.y - u.y) * s, z + (-r.z - u.z) * s).color(col);
        b.vertex(m, x + (r.x - u.x) * s, y + (r.y - u.y) * s, z + (r.z - u.z) * s).color(col);
        b.vertex(m, x + (r.x + u.x) * s, y + (r.y + u.y) * s, z + (r.z + u.z) * s).color(col);
        b.vertex(m, x + (-r.x + u.x) * s, y + (-r.y + u.y) * s, z + (-r.z + u.z) * s).color(col);
    }
}
