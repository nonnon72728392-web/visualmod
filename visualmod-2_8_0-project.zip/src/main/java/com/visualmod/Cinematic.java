package com.visualmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** Cinematic: виньетка, чёрные кинополосы и цветокоррекция поверх картинки (под HUD). */
public final class Cinematic {
    private Cinematic() {}

    private static float k = 0.0f;

    private static int argb(int rgb, float a) {
        int al = Math.max(0, Math.min(255, Math.round(a * 255.0f)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    public static void draw(DrawContext c, RenderTickCounter tc) {
        Anim.frame();
        k = Anim.smooth(k, Config.cinematic ? 1.0f : 0.0f, 5.0f);
        if (k < 0.004f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();

        // цветокоррекция
        float ta = Config.cvTintAmount * k;
        if (Config.cvTint != 0 && ta > 0.01f) {
            switch (Config.cvTint) {
                case 1 -> c.fill(0, 0, w, h, argb(0xFFA85A, 0.13f * ta * 2.0f));
                case 2 -> c.fill(0, 0, w, h, argb(0x5A9BFF, 0.13f * ta * 2.0f));
                case 3 -> c.fillGradient(0, 0, w, h, argb(0x1F7A96, 0.16f * ta * 2.0f), argb(0xFF8A3D, 0.16f * ta * 2.0f));
                default -> c.fill(0, 0, w, h, argb(Config.flow(0.0f), 0.12f * ta * 2.0f));
            }
        }

        // виньетка: затемнение к краям полосками с квадратичным спадом
        float v = Config.cvVignette * k;
        if (v > 0.01f) {
            int steps = 26;
            float depth = Math.min(w, h) * 0.42f;
            float sw = depth / steps;
            for (int i = 0; i < steps; i++) {
                float f = 1.0f - i / (float) steps;
                int col = argb(0x000000, 0.55f * v * f * f * f);
                int o = Math.round(i * sw), o2 = Math.round((i + 1) * sw);
                c.fill(o, 0, o2, h, col);                 // слева
                c.fill(w - o2, 0, w - o, h, col);         // справа
                c.fill(0, o, w, o2, col);                 // сверху
                c.fill(0, h - o2, w, h - o, col);         // снизу
            }
        }

        // кинополосы
        int bar = Math.round(h * Config.cvBars * k);
        if (bar > 0) {
            c.fill(0, 0, w, bar, 0xFF000000);
            c.fill(0, h - bar, w, h, 0xFF000000);
        }
    }
}
