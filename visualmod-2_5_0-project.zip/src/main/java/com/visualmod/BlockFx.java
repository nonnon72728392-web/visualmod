package com.visualmod;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;

/** Block Effect: анимированная подсветка блока, на который смотришь (Pulse / Scan / Corners). */
public final class BlockFx {
    private BlockFx() {}

    private static int argb(int rgb, float a) {
        int al = Math.max(0, Math.min(255, Math.round(a * 255.0f)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    public static void render(WorldRenderContext ctx) {
        if (!Config.blockFx) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;

        BlockPos pos = hit.getBlockPos();
        BlockState st = mc.world.getBlockState(pos);
        if (st.isAir()) return;
        boolean any = Config.bfFill || Config.bfOutline || Config.bfMode == 1;
        if (!any) return;

        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        VoxelShape shape = st.getOutlineShape(mc.world, pos);
        Box box = shape.isEmpty() ? new Box(0, 0, 0, 1, 1, 1) : shape.getBoundingBox();
        box = box.offset(pos).expand(0.003);

        Vec3d cam = ctx.camera().getPos();
        double time = (System.currentTimeMillis() % 100000L) / 1000.0 * Config.bfSpeed;
        float wave = 0.5f + 0.5f * (float) Math.sin(time * Math.PI * 2.0);
        int rgb = WorldFx.rgbOf(Config.bfColor, (float) ((time * 0.25) % 1.0));

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f m = ms.peek().getPositionMatrix();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        float x1 = (float) box.minX, y1 = (float) box.minY, z1 = (float) box.minZ;
        float x2 = (float) box.maxX, y2 = (float) box.maxY, z2 = (float) box.maxZ;

        switch (Config.bfMode) {
            case 1 -> {   // Scan: яркая полоса ходит вверх-вниз по граням
                if (Config.bfFill) solid(b, m, x1, y1, z1, x2, y2, z2, argb(rgb, 0.10f));
                float ph = (float) (time % 1.0);
                float tri = 1.0f - Math.abs(2.0f * ph - 1.0f);
                float h = y2 - y1;
                float cy = y1 + tri * h;
                float bh = Math.max(0.07f, h * 0.14f);
                float lo = Math.max(y1, cy - bh), hi = Math.min(y2, cy + bh);
                int clear = argb(rgb, 0.0f), bright = argb(rgb, 0.85f);
                band(b, m, x1, z1, x2, z1, lo, cy, hi, clear, bright);
                band(b, m, x1, z2, x2, z2, lo, cy, hi, clear, bright);
                band(b, m, x1, z1, x1, z2, lo, cy, hi, clear, bright);
                band(b, m, x2, z1, x2, z2, lo, cy, hi, clear, bright);
                if (Config.bfOutline) edges(b, m, x1, y1, z1, x2, y2, z2, 0.010f, 1.0f, argb(rgb, 0.9f));
            }
            case 2 -> {   // Corners: пульсирующие уголки
                if (Config.bfFill) solid(b, m, x1, y1, z1, x2, y2, z2, argb(rgb, 0.08f + 0.10f * wave));
                float len = 0.16f + 0.18f * wave;
                if (Config.bfOutline) edges(b, m, x1, y1, z1, x2, y2, z2, 0.014f, len, argb(rgb, 0.95f));
                else edges(b, m, x1, y1, z1, x2, y2, z2, 0.014f, len, argb(rgb, 0.95f));
            }
            default -> {  // Pulse: дышащая заливка + контур
                if (Config.bfFill) solid(b, m, x1, y1, z1, x2, y2, z2, argb(rgb, 0.10f + 0.22f * wave));
                if (Config.bfOutline) edges(b, m, x1, y1, z1, x2, y2, z2, 0.008f + 0.006f * wave, 1.0f, argb(rgb, 0.7f + 0.3f * wave));
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ms.pop();
    }

    // ------------------------------------------------------------ примитивы

    private static void v(BufferBuilder b, Matrix4f m, float x, float y, float z, int col) {
        b.vertex(m, x, y, z).color(col);
    }

    /** Закрашенный параллелепипед (6 граней). */
    private static void solid(BufferBuilder b, Matrix4f m, float x1, float y1, float z1,
                              float x2, float y2, float z2, int c) {
        v(b, m, x1, y1, z1, c); v(b, m, x2, y1, z1, c); v(b, m, x2, y1, z2, c); v(b, m, x1, y1, z2, c);
        v(b, m, x1, y2, z1, c); v(b, m, x1, y2, z2, c); v(b, m, x2, y2, z2, c); v(b, m, x2, y2, z1, c);
        v(b, m, x1, y1, z1, c); v(b, m, x1, y2, z1, c); v(b, m, x2, y2, z1, c); v(b, m, x2, y1, z1, c);
        v(b, m, x1, y1, z2, c); v(b, m, x2, y1, z2, c); v(b, m, x2, y2, z2, c); v(b, m, x1, y2, z2, c);
        v(b, m, x1, y1, z1, c); v(b, m, x1, y1, z2, c); v(b, m, x1, y2, z2, c); v(b, m, x1, y2, z1, c);
        v(b, m, x2, y1, z1, c); v(b, m, x2, y2, z1, c); v(b, m, x2, y2, z2, c); v(b, m, x2, y1, z2, c);
    }

    /** Полоса на вертикальной грани: снизу прозрачная, в центре яркая, сверху снова прозрачная. */
    private static void band(BufferBuilder b, Matrix4f m, float ax, float az, float bx, float bz,
                             float lo, float mid, float hi, int clear, int bright) {
        v(b, m, ax, lo, az, clear); v(b, m, bx, lo, bz, clear); v(b, m, bx, mid, bz, bright); v(b, m, ax, mid, az, bright);
        v(b, m, ax, mid, az, bright); v(b, m, bx, mid, bz, bright); v(b, m, bx, hi, bz, clear); v(b, m, ax, hi, az, clear);
    }

    /** 12 рёбер коробки толщиной t; frac < 1 даёт только уголки (по frac длины ребра с каждого конца). */
    private static void edges(BufferBuilder b, Matrix4f m, float x1, float y1, float z1,
                              float x2, float y2, float z2, float t, float frac, int c) {
        float[] ys = {y1, y2}, zs = {z1, z2}, xs = {x1, x2};
        for (float y : ys) {
            for (float z : zs) seg(b, m, x1, x2, y - t, y + t, z - t, z + t, 0, frac, c);   // ребро вдоль X
        }
        for (float x : xs) {
            for (float z : zs) seg(b, m, x - t, x + t, y1, y2, z - t, z + t, 1, frac, c);   // вдоль Y
        }
        for (float x : xs) {
            for (float y : ys) seg(b, m, x - t, x + t, y - t, y + t, z1, z2, 2, frac, c);   // вдоль Z
        }
    }

    private static void seg(BufferBuilder b, Matrix4f m, float x1, float x2, float y1, float y2, float z1, float z2,
                            int axis, float frac, int c) {
        if (frac >= 0.99f) {
            solid(b, m, x1, y1, z1, x2, y2, z2, c);
            return;
        }
        float len = axis == 0 ? x2 - x1 : axis == 1 ? y2 - y1 : z2 - z1;
        float d = Math.min(len * 0.5f, frac);   // длина уголка в блоках
        if (axis == 0) {
            solid(b, m, x1, y1, z1, x1 + d, y2, z2, c);
            solid(b, m, x2 - d, y1, z1, x2, y2, z2, c);
        } else if (axis == 1) {
            solid(b, m, x1, y1, z1, x2, y1 + d, z2, c);
            solid(b, m, x1, y2 - d, z1, x2, y2, z2, c);
        } else {
            solid(b, m, x1, y1, z1, x2, y2, z1 + d, c);
            solid(b, m, x1, y1, z2 - d, x2, y2, z2, c);
        }
    }
}
