package com.visualmod;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Box ESP: рамка с уголками и полоской здоровья вокруг игроков (и по желанию мобов).
 * Позиции считаются в мировом рендере, рисуются в HUD, поэтому рамка видна и сквозь стены.
 * Линии рисуются в физических пикселях окна - без "лесенки" GUI-масштаба.
 */
public final class Esp {
    private Esp() {}

    private record Frame(float x1, float y1, float x2, float y2, float hp, boolean player, String name, float dist, float hpAbs, int seed) {}

    private static final List<Frame> FRAMES = new ArrayList<>();

    public static boolean boxMode() {
        return Config.esp && Config.espMode != 1;
    }

    public static void collect(WorldRenderContext ctx) {
        FRAMES.clear();
        if (!boxMode()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        float td = ctx.tickCounter().getTickDelta(true);
        Vec3d cam = ctx.camera().getPos();
        Matrix4f view = ctx.positionMatrix();
        Matrix4f proj = ctx.projectionMatrix();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || e instanceof ArmorStandEntity) continue;
            boolean player = e instanceof PlayerEntity;
            if (!player && !Config.espMobs) continue;
            if (!le.isAlive()) continue;

            Vec3d lerp = e.getLerpedPos(td);
            Vec3d off = lerp.subtract(e.getPos());
            Box b = e.getBoundingBox();

            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE;
            float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
            boolean ok = true;
            for (int i = 0; i < 8 && ok; i++) {
                double cx = ((i & 1) == 0 ? b.minX : b.maxX) + off.x - cam.x;
                double cy = ((i & 2) == 0 ? b.minY : b.maxY) + off.y - cam.y;
                double cz = ((i & 4) == 0 ? b.minZ : b.maxZ) + off.z - cam.z;
                Vector4f v = new Vector4f((float) cx, (float) cy, (float) cz, 1.0f);
                v.mul(view);
                v.mul(proj);
                if (v.w <= 0.05f) {
                    ok = false;
                    break;
                }
                float sx = (v.x / v.w * 0.5f + 0.5f) * sw;
                float sy = (1.0f - (v.y / v.w * 0.5f + 0.5f)) * sh;
                minX = Math.min(minX, sx);
                maxX = Math.max(maxX, sx);
                minY = Math.min(minY, sy);
                maxY = Math.max(maxY, sy);
            }
            if (!ok) continue;
            if (maxX < -20 || minX > sw + 20 || maxY < -20 || minY > sh + 20) continue;

            float hp = MathHelper.clamp(le.getHealth() / Math.max(1.0f, le.getMaxHealth()), 0.0f, 1.0f);
            FRAMES.add(new Frame(minX, minY, maxX, maxY, hp, player, e.getName().getString(),
                    (float) mc.player.distanceTo(e), le.getHealth() + le.getAbsorptionAmount(), e.getId()));
        }
    }

    public static void draw(DrawContext c, RenderTickCounter tickCounter) {
        if (!boxMode() || FRAMES.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        Anim.frame();

        boolean fancy = Config.espMode == 2;
        float px = 1.0f / Ui.scale();   // один физический пиксель в GUI-координатах
        long now = System.currentTimeMillis();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        for (Frame f : FRAMES) {
            float x1 = f.x1(), y1 = f.y1(), x2 = f.x2(), y2 = f.y2();
            float w = x2 - x1, h = y2 - y1;
            if (w < 4 || h < 4) continue;

            float pulse = Config.espPulse ? 0.8f + 0.2f * (float) Math.sin(now / 380.0 + f.seed()) : 1.0f;
            float op = Config.espOpacity * pulse;
            int rgb = f.player() ? WorldFx.rgbOf(Config.espColor, (f.seed() % 100) / 100.0f) : 0xFFFFFF;
            int rgb2 = f.player() ? WorldFx.rgbOf(Config.espColor, ((f.seed() % 100) / 100.0f) + 0.18f) : 0xB0B0FF;
            int col = Ui.alpha(rgb, op);

            if (tracerOn()) tracer(c, sw / 2.0f, sh - 2.0f, (x1 + x2) / 2.0f, y2, Ui.alpha(rgb, 0.55f * op), px);

            if (Config.espFill) {
                if (fancy) {
                    // вертикальный градиент: сверху почти прозрачный, снизу насыщенный
                    gradient(c, x1, y1, x2, y2, Ui.alpha(rgb, 0.02f), Ui.alpha(rgb2, 0.26f * op));
                } else {
                    Ui.rrectF(c, x1, y1, w, h, Math.min(6.0f, Math.min(w, h) / 3.0f), (col & 0xFFFFFF) | 0x14000000);
                }
            }

            float len = Math.max(4.0f, Math.min(w, h) / 4.0f);
            float t = px * 2.0f;            // толщина линии 2 физических пикселя

            if (Config.espGlowLayer) {
                // мягкое свечение: несколько расширяющихся контуров с падающей прозрачностью
                for (int k = 4; k >= 1; k--) {
                    float pad = k * px * 1.6f;
                    int gc = Ui.alpha(rgb, (0.12f / k) * op);
                    outline(c, x1 - pad, y1 - pad, x2 + pad, y2 + pad, px * 1.6f, gc);
                }
            }

            if (fancy) {
                outline(c, x1, y1, x2, y2, px, Ui.alpha(rgb, 0.35f * op));        // тонкая полная рамка
                corners(c, x1, y1, x2, y2, len, 0xFF000000, t, px);                // подложка
                cornersGrad(c, x1, y1, x2, y2, len, Ui.alpha(rgb, op), Ui.alpha(rgb2, op), t);
            } else {
                corners(c, x1, y1, x2, y2, len, 0xFF000000, t, px);
                corners(c, x1, y1, x2, y2, len, col | 0xFF000000, t, 0.0f);
            }

            if (Config.espHealth) {
                float bx = x1 - 5.0f;
                Ui.rect(c, bx - px, y1 - px, bx + px * 3.0f, y2 + px, 0xB0000000);
                float fill = h * f.hp();
                if (fancy) {
                    int top = 0xFF000000 | MathHelper.hsvToRgb(f.hp() * 0.33f, 0.7f, 1.0f);
                    int bot = 0xFF000000 | MathHelper.hsvToRgb(Math.max(0.0f, f.hp() * 0.33f - 0.12f), 0.85f, 0.85f);
                    gradient(c, bx, y2 - fill, bx + px * 2.0f, y2, top, bot);
                } else {
                    Ui.rect(c, bx, y2 - fill, bx + px * 2.0f, y2, 0xFF000000 | MathHelper.hsvToRgb(f.hp() * 0.33f, 0.75f, 1.0f));
                }
            }

            if (fancy && (Config.espName || Config.espDistance)) {
                String label = Config.espName ? f.name() : "";
                if (Config.espDistance) label += (label.isEmpty() ? "" : "  ") + Math.round(f.dist()) + "m";
                int tw = Ui.width(mc.textRenderer, label);
                int bw = tw + 14, bh = 13;
                float bxl = (x1 + x2) / 2.0f - bw / 2.0f;
                float byl = y1 - bh - 4.0f;
                Ui.rrectF(c, bxl, byl, bw, bh, bh / 2.0f, Ui.alpha(0x0E0E16, 0.72f));
                Ui.rrectF(c, bxl, byl + bh - 1.5f, bw, 1.5f, 0.7f, Ui.alpha(rgb, 0.9f));
                Ui.textMidF(c, mc.textRenderer, label, bxl + 7, byl, bh, 0xFFF2F2FA);
            }
        }
    }

    private static boolean tracerOn() {
        return Config.espTracer;
    }

    /** Линия от точки к точке из повёрнутого прямоугольника. */
    private static void tracer(DrawContext c, float ax, float ay, float bx, float by, int color, float px) {
        float dx = bx - ax, dy = by - ay;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 2.0f) return;
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(ax, ay, 0.0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotation((float) Math.atan2(dy, dx)));
        Ui.rect(c, 0.0f, -px, len, px, color);
        m.pop();
    }

    /** Градиент сверху вниз в физических пикселях. */
    private static void gradient(DrawContext c, float x1, float y1, float x2, float y2, int top, int bottom) {
        float s = Ui.scale();
        MatrixStack m = c.getMatrices();
        m.push();
        m.scale(1.0f / s, 1.0f / s, 1.0f);
        int X1 = Math.round(x1 * s), Y1 = Math.round(y1 * s), X2 = Math.round(x2 * s), Y2 = Math.round(y2 * s);
        if (X2 > X1 && Y2 > Y1) c.fillGradient(X1, Y1, X2, Y2, top, bottom);
        m.pop();
    }

    private static void outline(DrawContext c, float x1, float y1, float x2, float y2, float t, int color) {
        Ui.rect(c, x1, y1, x2, y1 + t, color);
        Ui.rect(c, x1, y2 - t, x2, y2, color);
        Ui.rect(c, x1, y1 + t, x1 + t, y2 - t, color);
        Ui.rect(c, x2 - t, y1 + t, x2, y2 - t, color);
    }

    /** Уголки, у которых цвет плавно переходит от верха (a) к низу (b). */
    private static void cornersGrad(DrawContext c, float x1, float y1, float x2, float y2,
                                    float len, int a, int b, float t) {
        // верхние уголки - цвет a, нижние - цвет b, вертикальные плечи с градиентом
        Ui.rect(c, x1, y1, x1 + len, y1 + t, a);
        Ui.rect(c, x2 - len, y1, x2, y1 + t, a);
        Ui.rect(c, x1, y2 - t, x1 + len, y2, b);
        Ui.rect(c, x2 - len, y2 - t, x2, y2, b);
        gradient(c, x1, y1, x1 + t, y1 + len, a, Ui.mix(a, b, 0.5f));
        gradient(c, x2 - t, y1, x2, y1 + len, a, Ui.mix(a, b, 0.5f));
        gradient(c, x1, y2 - len, x1 + t, y2, Ui.mix(a, b, 0.5f), b);
        gradient(c, x2 - t, y2 - len, x2, y2, Ui.mix(a, b, 0.5f), b);
    }

    /** pad > 0 рисует подложку шире линии со всех сторон. */
    private static void corners(DrawContext c, float x1, float y1, float x2, float y2,
                                float len, int color, float t, float pad) {
        float p = pad;
        // левый верх
        Ui.rect(c, x1 - p, y1 - p, x1 + len + p, y1 + t + p, color);
        Ui.rect(c, x1 - p, y1 - p, x1 + t + p, y1 + len + p, color);
        // правый верх
        Ui.rect(c, x2 - len - p, y1 - p, x2 + p, y1 + t + p, color);
        Ui.rect(c, x2 - t - p, y1 - p, x2 + p, y1 + len + p, color);
        // левый низ
        Ui.rect(c, x1 - p, y2 - t - p, x1 + len + p, y2 + p, color);
        Ui.rect(c, x1 - p, y2 - len - p, x1 + t + p, y2 + p, color);
        // правый низ
        Ui.rect(c, x2 - len - p, y2 - t - p, x2 + p, y2 + p, color);
        Ui.rect(c, x2 - t - p, y2 - len - p, x2 + p, y2 + p, color);
    }
}
