package com.visualmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * Меню мода в виде плавающих панелей-категорий.
 * ЛКМ по модулю - вкл/выкл, ПКМ - раскрыть настройки, ПКМ по заголовку - свернуть панель,
 * заголовок можно таскать, колесо мыши листает длинные панели.
 * Эффекты: фоновые частицы с линиями (отталкиваются от курсора), след курсора, волна от клика,
 * свечение включённых модулей, волна появления панелей, анимированная линия заголовка.
 */
public class ClickGuiScreen extends Screen {
    private static final int PW = 152;      // ширина панели
    private static final int HEAD = 24;     // высота заголовка
    private static final int STRIDE = 22;   // шаг строк
    private static final int RH = 20;       // высота строки
    private static final int GAP = 10;

    private static final int BORDER = 0xFF2C2C3A;
    private static final int BG = 0xF012121A;
    private static final int HEAD_BG = 0xF0181822;
    private static final int PANEL = 0xFF1E1E29;
    private static final int PANEL_HOVER = 0xFF2A2A38;
    private static final int OFF = 0xFF3C3C4C;
    private static final int TEXT = 0xFFEDEDF5;
    private static final int MUTED = 0xFF8E8E9F;

    private static final String[] TAB_NAMES = {"Visuals", "World", "Hands", "Combat", "Misc", "HUD", "Style"};

    // положение панелей запоминается между открытиями
    private static float[] savedX = null, savedY = null;
    private static boolean[] savedCollapsed = null;

    // фоновые частицы
    private static final class Dot { float x, y, vx, vy, r; }
    private final List<Dot> dots = new ArrayList<>();
    private final Random rnd = new Random();

    // след курсора и волны от кликов
    private final float[][] trail = new float[16][3];   // x, y, время появления (мс)
    private int trailN = 0;
    private float lastTx = -1, lastTy = -1;
    private final List<float[]> ripples = new ArrayList<>();   // x, y, время (мс)

    private final List<Panel> panels = new ArrayList<>();
    private final List<Hit> hits = new ArrayList<>();
    private Row dragging = null;
    private Panel movingPanel = null;
    private float moveOffX, moveOffY;
    private BindRow listening = null;

    private float openT = 0.0f;
    private long openAt = 0L;

    public ClickGuiScreen() {
        super(Text.literal("noomidls"));
    }

    private class Panel {
        final int idx;
        final String name;
        final List<Row> rows;
        float x, y;
        boolean collapsed = false;
        float col = 1.0f;       // анимация сворачивания
        float scroll = 0.0f, scrollT = 0.0f;
        // прямоугольник последнего кадра (для попаданий мыши)
        int rx, ry, rw, rh, bodyTop, bodyBottom;

        Panel(int idx, String name, List<Row> rows) {
            this.idx = idx;
            this.name = name;
            this.rows = rows;
        }

        int contentHeight() {
            int h = 4;
            for (Row r : rows) h += r.height();
            return h;
        }
    }

    private static final class Hit {
        Row row;
        Toggle parent;
        Panel panel;
        int x, y, w;
        boolean header;
    }

    // ------------------------------------------------------------ строки меню

    private abstract class Row {
        float hv = 0.0f;

        float hover(boolean in) {
            hv = Anim.step(hv, in ? 1.0f : 0.0f, 16.0f);
            return hv;
        }

        int height() { return STRIDE; }
        abstract void render(DrawContext c, int x, int y, int w, int mx, int my);
        boolean click(int x, int y, int w, double mx, double my) { return false; }
        void drag(double mx) {}
    }

    private class Toggle extends Row {
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;
        List<Row> settings = null;   // != null -> у модуля есть настройки (ПКМ раскрывает)
        boolean expanded = false;
        float ex = 0.0f;             // анимация раскрытия 0..1
        float knob = -1.0f;
        float pulse = 0.0f;          // вспышка при включении

        Toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
            this.label = label;
            this.get = get;
            this.set = set;
        }

        Toggle with(Row... rows) {
            this.settings = new ArrayList<>(Arrays.asList(rows));
            return this;
        }

        int settingsHeight() {
            int h = 0;
            if (settings != null) for (Row r : settings) h += r.height();
            return h;
        }

        /** Один раз за кадр: двигает анимацию раскрытия. */
        void tickExpand() {
            if (settings != null) ex = Anim.step(ex, expanded ? 1.0f : 0.0f, 16.0f);
        }

        @Override
        int height() {
            if (settings == null) return STRIDE;
            return STRIDE + Math.round((settingsHeight() + 4) * ex);
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            boolean on = get.getAsBoolean();
            if (knob < 0.0f) knob = on ? 1.0f : 0.0f;
            float prev = knob;
            knob = Anim.step(knob, on ? 1.0f : 0.0f, 14.0f);
            if (on && prev < 0.5f && knob >= 0.5f) pulse = 1.0f;
            pulse = Anim.smooth(pulse, 0.0f, 5.0f);
            float hv = hover(Ui.in(mx, my, x, y, w, RH));
            int accent = Config.accent();

            if (knob > 0.02f && Config.guiGlow) {
                for (int k = 3; k >= 1; k--) {
                    Ui.rrectF(c, x - k, y - k, w + k * 2, RH + k * 2, 7 + k,
                            Ui.alpha(accent, (0.06f + 0.10f * pulse) * knob / k));
                }
            }
            Ui.rrectF(c, x, y, w, RH, 6, Ui.mix(PANEL, PANEL_HOVER, hv));
            if (knob > 0.01f) {
                float fw = Math.max(RH * 0.7f, w * knob);
                int a2 = Ui.mix(accent, 0xFFFFFFFF, 0.18f + 0.3f * pulse);
                Ui.rrectF(c, x, y, fw, RH, 6, Ui.mix(Ui.alpha(accent, 0.0f), accent, Math.min(1.0f, knob * 1.4f)));
                Ui.rrectF(c, x, y, fw, RH / 2.0f, 6, Ui.alpha(a2, 0.35f * knob));
            }
            Ui.textMid(c, textRenderer, label, x + 9 + Math.round(2 * hv), y, RH,
                    Ui.mix(MUTED, 0xFFFFFFFF, Math.max(knob, hv * 0.6f)));

            if (settings != null) {
                // шеврон: поворачивается при раскрытии
                int cx = x + w - 11, cy = y + RH / 2;
                float rot = ex;
                for (int i = -2; i <= 2; i++) {
                    float off = Math.abs(i) * (1.0f - 2.0f * rot) * 0.9f;   // v -> ^ плавно
                    Ui.rrectF(c, cx + i * 1.4f - 0.7f, cy - 1.5f + off, 1.6f, 1.6f, 0.8f,
                            Ui.mix(MUTED, 0xFFFFFFFF, Math.max(knob, hv)));
                }
            }
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                set.accept(!get.getAsBoolean());
                return true;
            }
            return false;
        }
    }

    private class Cycle extends Row {
        final String label;
        final String[] options;
        final IntSupplier get;
        final IntConsumer set;

        Cycle(String label, String[] options, IntSupplier get, IntConsumer set) {
            this.label = label;
            this.options = options;
            this.get = get;
            this.set = set;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, Ui.mix(PANEL, PANEL_HOVER, hover(Ui.in(mx, my, x, y, w, RH))));
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, TEXT);
            String v = options[Math.floorMod(get.getAsInt(), options.length)];
            int vw = Ui.width(textRenderer, v) + 16;
            int vx = x + w - vw - 4;
            Ui.capsule(c, vx, y + 3, vw, RH - 6, Config.accent());
            Ui.textMid(c, textRenderer, v, vx + 8, y, RH, 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                set.accept(Math.floorMod(get.getAsInt() + 1, options.length));
                return true;
            }
            return false;
        }
    }

    private class Slider extends Row {
        final String label;
        final float min, max;
        final String fmt;
        final Supplier<Float> get;
        final Consumer<Float> set;
        int trackX, trackW;

        Slider(String label, float min, float max, String fmt, Supplier<Float> get, Consumer<Float> set) {
            this.label = label;
            this.min = min;
            this.max = max;
            this.fmt = fmt;
            this.get = get;
            this.set = set;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, PANEL);
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, TEXT);

            String value = String.format(fmt, get.get());
            Ui.textMid(c, textRenderer, value, x + w - 12 - Ui.width(textRenderer, value), y, RH, MUTED);

            trackX = x + 74;
            trackW = w - 74 - 54;
            float t = (get.get() - min) / (max - min);
            t = Math.max(0f, Math.min(1f, t));
            float fill = trackW * t;
            int ty = y + (RH - 4) / 2;
            Ui.capsuleF(c, trackX, ty, trackW, 4, OFF);
            if (fill > 0) Ui.capsuleF(c, trackX, ty, Math.max(4.0f, fill), 4, Config.accent());
            Ui.capsuleF(c, trackX + fill - 4, y + (RH - 8) / 2.0f, 8, 8, 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, trackX - 6, y, trackW + 12, RH)) {
                drag(mx);
                return true;
            }
            return false;
        }

        @Override
        void drag(double mx) {
            float t = (float) ((mx - trackX) / trackW);
            t = Math.max(0f, Math.min(1f, t));
            set.accept(min + t * (max - min));
        }
    }

    private class Button extends Row {
        final String label;
        final Runnable action;

        Button(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            float hv = hover(Ui.in(mx, my, x, y, w, RH));
            Ui.capsule(c, x, y, w, RH, Ui.mix(PANEL_HOVER, Config.accent(), hv));
            int tw = Ui.width(textRenderer, label);
            Ui.textMid(c, textRenderer, label, x + (w - tw) / 2, y, RH, TEXT);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                action.run();
                return true;
            }
            return false;
        }
    }

    /** Выбор клавиши / кнопки мыши. Клик -> нажми нужную кнопку. Esc = очистить. */
    private class BindRow extends Row {
        final String label;
        final IntSupplier get;
        final IntConsumer set;

        BindRow(String label, IntSupplier get, IntConsumer set) {
            this.label = label;
            this.get = get;
            this.set = set;
        }

        String name(int code) {
            if (code == -1) return "None";
            if (code <= -100) {
                int b = -100 - code;
                return b == 0 ? "LMB" : b == 1 ? "RMB" : b == 2 ? "MMB" : "Mouse " + (b + 1);
            }
            return InputUtil.fromKeyCode(code, -1).getLocalizedText().getString();
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, Ui.mix(PANEL, PANEL_HOVER, hover(Ui.in(mx, my, x, y, w, RH))));
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, TEXT);
            boolean wait = listening == this;
            String v = wait ? "Press..." : name(get.getAsInt());
            int vw = Ui.width(textRenderer, v) + 16;
            int vx = x + w - vw - 4;
            Ui.capsule(c, vx, y + 3, vw, RH - 6, wait ? 0xFFFFFFFF : Config.accent());
            Ui.textMid(c, textRenderer, v, vx + 8, y, RH, wait ? 0xFF14141B : 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                listening = this;
                return true;
            }
            return false;
        }
    }

    private class Note extends Row {
        final String text;

        Note(String text) {
            this.text = text;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.textMid(c, textRenderer, text, x + 12, y, RH, MUTED);
        }
    }

    private class AccentPicker extends Row {
        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, Ui.mix(PANEL, PANEL_HOVER, hover(Ui.in(mx, my, x, y, w, RH))));
            Ui.textMid(c, textRenderer, "Accent color", x + 12, y, RH, TEXT);
            String name = Config.accentName();
            int nw = Ui.width(textRenderer, name);
            Ui.textMid(c, textRenderer, name, x + w - 12 - nw, y, RH, MUTED);
            Ui.capsule(c, x + w - 12 - nw - 16, y + (RH - 10) / 2, 10, 10, Config.accent());
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                Config.accent++;
                return true;
            }
            return false;
        }
    }

    // ------------------------------------------------------------ экран

    private Slider slider(String label, float min, float max, String fmt, Supplier<Float> g, Consumer<Float> s) {
        return new Slider(label, min, max, fmt, g, s);
    }

    private Toggle toggle(String label, BooleanSupplier g, Consumer<Boolean> s) {
        return new Toggle(label, g, s);
    }

    /** Модуль из общего списка: включатель + настройки (ПКМ) с клавишей включения в конце. */
    private Toggle mod(String id, Row... rows) {
        Modules.Mod m = Modules.get(id);
        List<Row> all = new ArrayList<>(Arrays.asList(rows));
        all.add(new BindRow("Toggle key", () -> Config.bind(id), v -> Config.setBind(id, v)));
        Toggle t = new Toggle(m.label(), m.get(), m.set());
        t.settings = all;
        return t;
    }

    @Override
    protected void init() {
        List<List<Row>> pages = new ArrayList<>();
        listening = null;
        dragging = null;
        movingPanel = null;

        // ---- Visuals
        List<Row> visuals = new ArrayList<>();
        visuals.add(mod("esp",
                new Cycle("Mode", new String[]{"Corners", "Glow", "Fancy"}, () -> Config.espMode, v -> Config.espMode = v),
                new Cycle("Color", Config.COLOR_MODES, () -> Config.espColor, v -> Config.espColor = v),
                slider("Opacity", 0.2f, 1.0f, "%.2f", () -> Config.espOpacity, v -> Config.espOpacity = v),
                toggle("Mobs", () -> Config.espMobs, v -> Config.espMobs = v),
                toggle("Fill", () -> Config.espFill, v -> Config.espFill = v),
                toggle("Health bar", () -> Config.espHealth, v -> Config.espHealth = v),
                toggle("Name + distance", () -> Config.espName, v -> { Config.espName = v; Config.espDistance = v; }),
                toggle("Soft glow", () -> Config.espGlowLayer, v -> Config.espGlowLayer = v),
                toggle("Pulse", () -> Config.espPulse, v -> Config.espPulse = v),
                toggle("Tracers", () -> Config.espTracer, v -> Config.espTracer = v)));
        visuals.add(mod("seeinv",
                toggle("Players only", () -> Config.siPlayersOnly, v -> Config.siPlayersOnly = v)));
        visuals.add(mod("nametags",
                slider("Scale", 0.6f, 1.8f, "%.2f", () -> Config.ntScale, v -> Config.ntScale = v),
                slider("Background", 0.0f, 1.0f, "%.2f", () -> Config.ntBg, v -> Config.ntBg = v),
                toggle("Health", () -> Config.ntHealth, v -> Config.ntHealth = v),
                toggle("Distance", () -> Config.ntDistance, v -> Config.ntDistance = v),
                toggle("Potions", () -> Config.ntPotions, v -> Config.ntPotions = v)));
        visuals.add(mod("fullbright",
                new Note("Клиентское ночное зрение")));
        visuals.add(mod("itemphysics",
                slider("Spin", 0.0f, 3.0f, "%.1f", () -> Config.ipSpin, v -> Config.ipSpin = v)));
        pages.add(visuals);

        // ---- World
        List<Row> world = new ArrayList<>();
        world.add(mod("particles",
                new Cycle("Mode", Config.FX_MODES, () -> Config.fxMode, v -> Config.fxMode = v),
                new Cycle("Color", Config.COLOR_MODES, () -> Config.fxColor, v -> Config.fxColor = v),
                slider("Amount", 0.3f, 3.0f, "%.1f", () -> Config.fxAmount, v -> Config.fxAmount = v),
                slider("Size", 0.4f, 2.5f, "%.1f", () -> Config.fxSize, v -> Config.fxSize = v),
                toggle("Other players", () -> Config.fxOthers, v -> Config.fxOthers = v)));
        world.add(mod("jumpcircle",
                new Cycle("Color", Config.COLOR_MODES, () -> Config.jcColor, v -> Config.jcColor = v),
                slider("Radius", 0.8f, 3.5f, "%.1f", () -> Config.jcRadius, v -> Config.jcRadius = v),
                slider("Time", 0.4f, 2.5f, "%.1fs", () -> Config.jcDuration, v -> Config.jcDuration = v),
                toggle("Other players", () -> Config.jcOthers, v -> Config.jcOthers = v)));
        world.add(mod("chinahat",
                new Cycle("Color", Config.COLOR_MODES, () -> Config.chColor, v -> Config.chColor = v),
                slider("Radius", 0.3f, 0.95f, "%.2f", () -> Config.chRadius, v -> Config.chRadius = v),
                slider("Height", 0.15f, 0.9f, "%.2f", () -> Config.chHeight, v -> Config.chHeight = v),
                slider("Opacity", 0.15f, 1.0f, "%.2f", () -> Config.chAlpha, v -> Config.chAlpha = v),
                toggle("Other players", () -> Config.chOthers, v -> Config.chOthers = v)));
        world.add(mod("noparticles",
                toggle("Keep totem", () -> Config.npKeepTotem, v -> Config.npKeepTotem = v),
                toggle("Keep hit/crit", () -> Config.npKeepHit, v -> Config.npKeepHit = v),
                new Note("Ванильные частицы не создаются")));
        world.add(mod("nohurtcam",
                toggle("Also no bobbing", () -> Config.noBob, v -> Config.noBob = v)));
        world.add(mod("nofire",
                new Note("Огонь не закрывает экран")));
        pages.add(world);

        // ---- Hands
        List<Row> hands = new ArrayList<>();
        hands.add(mod("viewmodel",
                slider("X", -1.0f, 1.0f, "%.2f", () -> Config.vmX, v -> Config.vmX = v),
                slider("Y", -1.0f, 1.0f, "%.2f", () -> Config.vmY, v -> Config.vmY = v),
                slider("Z", -1.5f, 0.5f, "%.2f", () -> Config.vmZ, v -> Config.vmZ = v),
                slider("Scale", 0.3f, 1.5f, "%.2f", () -> Config.vmScale, v -> Config.vmScale = v),
                new Button("Reset viewmodel", Config::resetViewModel)));
        hands.add(mod("swing",
                new Cycle("Style", Config.SWING_STYLES, () -> Config.swingStyle, v -> Config.swingStyle = v),
                slider("Speed", 2.0f, 20.0f, "%.0f", () -> Config.swingSpeed, v -> Config.swingSpeed = (float) Math.round(v)),
                slider("Angle", -60.0f, 60.0f, "%.0f", () -> Config.swingAngle, v -> Config.swingAngle = (float) Math.round(v)),
                toggle("Bounce", () -> Config.swingBounce, v -> Config.swingBounce = v)));
        pages.add(hands);

        // ---- Combat
        List<Row> combat = new ArrayList<>();
        combat.add(mod("killaura",
                slider("Range", 2.5f, 6.0f, "%.1f", () -> Config.kaRange, v -> Config.kaRange = Math.round(v * 10.0f) / 10.0f),
                slider("Charge", 0.1f, 1.0f, "%.2f", () -> Config.kaCharge, v -> Config.kaCharge = v),
                slider("Delay", 0.0f, 10.0f, "%.0ft", () -> Config.kaDelay, v -> Config.kaDelay = (float) Math.round(v)),
                slider("FOV", 30.0f, 360.0f, "%.0f", () -> Config.kaFov, v -> Config.kaFov = (float) Math.round(v)),
                slider("Turn speed", 2.0f, 60.0f, "%.0f", () -> Config.kaRotSpeed, v -> Config.kaRotSpeed = (float) Math.round(v)),
                new Cycle("Sort", Config.KA_SORTS, () -> Config.kaSort, v -> Config.kaSort = v),
                toggle("Rotate", () -> Config.kaRotate, v -> Config.kaRotate = v),
                toggle("Include mobs", () -> Config.kaMobs, v -> Config.kaMobs = v),
                toggle("Through walls", () -> Config.kaWalls, v -> Config.kaWalls = v),
                toggle("Swing hand", () -> Config.kaSwing, v -> Config.kaSwing = v),
                toggle("Target mark", () -> Config.kaMark, v -> Config.kaMark = v)));
        combat.add(mod("hitinfo",
                slider("Hold", 3.0f, 30.0f, "%.0fs", () -> Config.hiHold, v -> Config.hiHold = (float) Math.round(v)),
                toggle("Show name", () -> Config.hiName, v -> Config.hiName = v),
                toggle("Last hit", () -> Config.hiLast, v -> Config.hiLast = v),
                toggle("Healed (+)", () -> Config.hiHealed, v -> Config.hiHealed = v),
                toggle("Health bar", () -> Config.hiBar, v -> Config.hiBar = v),
                new Button("Reset stats", HitInfo::reset)));
        combat.add(mod("triggerbot",
                slider("Charge", 0.1f, 1.0f, "%.2f", () -> Config.tbCharge, v -> Config.tbCharge = v),
                slider("Delay", 0.0f, 10.0f, "%.0ft", () -> Config.tbDelay, v -> Config.tbDelay = (float) Math.round(v)),
                toggle("Players only", () -> Config.tbPlayersOnly, v -> Config.tbPlayersOnly = v)));
        combat.add(mod("autototem",
                slider("Delay", 0.0f, 10.0f, "%.0ft", () -> Config.atDelay, v -> Config.atDelay = (float) Math.round(v)),
                slider("Health", 0.0f, 20.0f, "%.0f", () -> Config.atHealth, v -> Config.atHealth = (float) Math.round(v)),
                toggle("Only if offhand empty", () -> Config.atEmptyOnly, v -> Config.atEmptyOnly = v),
                new Note("Health 0 = тотем всегда в руке")));
        combat.add(mod("clickpearl",
                new BindRow("Throw key", () -> Config.cpBind, v -> Config.cpBind = v),
                toggle("Swing hand", () -> Config.cpSwing, v -> Config.cpSwing = v)));
        combat.add(mod("clickwind",
                new BindRow("Use key", () -> Config.cwBind, v -> Config.cwBind = v),
                toggle("Aim down", () -> Config.cwAimDown, v -> Config.cwAimDown = v),
                toggle("Swing hand", () -> Config.cwSwing, v -> Config.cwSwing = v)));
        pages.add(combat);

        // ---- Misc
        List<Row> misc = new ArrayList<>();
        misc.add(mod("autosprint",
                new Note("Держит бег при ходьбе вперёд")));
        misc.add(mod("autorespawn",
                slider("Delay", 0.0f, 40.0f, "%.0ft", () -> Config.arDelay, v -> Config.arDelay = (float) Math.round(v))));
        misc.add(mod("zoom",
                new BindRow("Zoom key", () -> Config.zoomBind, v -> Config.zoomBind = v),
                slider("Level", 1.5f, 10.0f, "%.1fx", () -> Config.zoomLevel, v -> Config.zoomLevel = v),
                toggle("Smooth", () -> Config.zoomSmooth, v -> Config.zoomSmooth = v)));
        pages.add(misc);

        // ---- HUD
        List<Row> hud = new ArrayList<>();
        hud.add(toggle("HUD", () -> Config.hud, v -> Config.hud = v).with(
                new Button("Move HUD", () -> client.setScreen(new HudEditorScreen())),
                new Button("Reset HUD positions", Config::resetHud)));
        hud.add(toggle("Watermark", () -> Config.hudWatermark, v -> Config.hudWatermark = v).with(
                toggle("FPS", () -> Config.hudFps, v -> Config.hudFps = v),
                toggle("Ping", () -> Config.hudPing, v -> Config.hudPing = v)));
        hud.add(toggle("Module list", () -> Config.hudModuleList, v -> Config.hudModuleList = v).with(
                toggle("Dots", () -> Config.mlDots, v -> Config.mlDots = v)));
        hud.add(toggle("Coordinates", () -> Config.hudInfo, v -> Config.hudInfo = v).with(
                toggle("Facing (N/E/S/W)", () -> Config.hudFacing, v -> Config.hudFacing = v)));
        hud.add(toggle("Keystrokes", () -> Config.hudKeys, v -> Config.hudKeys = v).with(
                toggle("Space bar", () -> Config.ksSpace, v -> Config.ksSpace = v)));
        hud.add(toggle("Armor", () -> Config.hudArmor, v -> Config.hudArmor = v).with(
                toggle("Vertical", () -> Config.haVertical, v -> Config.haVertical = v),
                toggle("Durability bar", () -> Config.haDurability, v -> Config.haDurability = v)));
        hud.add(toggle("Potions", () -> Config.hudPotions, v -> Config.hudPotions = v).with(
                toggle("Timer", () -> Config.hpTimer, v -> Config.hpTimer = v)));
        hud.add(toggle("Item counters", () -> Config.hudCounts, v -> Config.hudCounts = v).with(
                toggle("Totems", () -> Config.ctTotem, v -> Config.ctTotem = v),
                toggle("Ender pearls", () -> Config.ctPearl, v -> Config.ctPearl = v),
                toggle("Wind charges", () -> Config.ctWind, v -> Config.ctWind = v)));
        pages.add(hud);

        // ---- Style
        List<Row> style = new ArrayList<>();
        style.add(new Cycle("Font", Config.FONT_NAMES, () -> Config.font, v -> Config.font = v));
        style.add(new AccentPicker());
        style.add(toggle("Menu animations", () -> Config.uiAnim, v -> Config.uiAnim = v));
        style.add(toggle("Menu particles", () -> Config.guiParticles, v -> Config.guiParticles = v));
        style.add(toggle("Menu glow", () -> Config.guiGlow, v -> Config.guiGlow = v));
        style.add(toggle("Click ripple", () -> Config.guiRipple, v -> Config.guiRipple = v));
        style.add(toggle("Background fade", () -> Config.guiBlur, v -> Config.guiBlur = v));
        style.add(new Button("Move HUD", () -> client.setScreen(new HudEditorScreen())));
        style.add(new Button("Reset HUD positions", Config::resetHud));
        pages.add(style);

        // панели
        panels.clear();
        if (savedX == null || savedX.length != TAB_NAMES.length) {
            savedX = new float[TAB_NAMES.length];
            savedY = new float[TAB_NAMES.length];
            savedCollapsed = new boolean[TAB_NAMES.length];
            float cx = GAP, cy = 26;
            for (int i = 0; i < TAB_NAMES.length; i++) {
                if (cx + PW > width - 4 && cx > GAP) {
                    cx = GAP;
                    cy += 150;
                }
                savedX[i] = cx;
                savedY[i] = cy;
                cx += PW + GAP;
            }
        }
        for (int i = 0; i < TAB_NAMES.length; i++) {
            Panel p = new Panel(i, TAB_NAMES[i], pages.get(i));
            p.x = savedX[i];
            p.y = savedY[i];
            p.collapsed = savedCollapsed[i];
            p.col = p.collapsed ? 0.0f : 1.0f;
            panels.add(p);
        }
        clamp();

        // фоновые частицы
        dots.clear();
        int n = Math.max(30, Math.min(90, width * height / 9000));
        for (int i = 0; i < n; i++) {
            Dot d = new Dot();
            d.x = rnd.nextFloat() * width;
            d.y = rnd.nextFloat() * height;
            float a = rnd.nextFloat() * 6.2831f;
            float sp = 4.0f + rnd.nextFloat() * 10.0f;
            d.vx = (float) Math.cos(a) * sp;
            d.vy = (float) Math.sin(a) * sp;
            d.r = 0.8f + rnd.nextFloat() * 1.4f;
            dots.add(d);
        }
        openAt = System.currentTimeMillis();
        openT = 0.0f;
    }

    private void clamp() {
        for (Panel p : panels) {
            p.x = Math.max(0, Math.min(p.x, Math.max(0, width - PW)));
            p.y = Math.max(0, Math.min(p.y, Math.max(0, height - HEAD)));
        }
    }

    private void saveLayout() {
        if (savedX == null) return;
        for (Panel p : panels) {
            savedX[p.idx] = p.x;
            savedY[p.idx] = p.y;
            savedCollapsed[p.idx] = p.collapsed;
        }
    }

    // ------------------------------------------------------------ рисование эффектов

    private static void line(DrawContext c, float ax, float ay, float bx, float by, int color) {
        float dx = bx - ax, dy = by - ay;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1.0f) return;
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(ax, ay, 0.0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotation((float) Math.atan2(dy, dx)));
        Ui.rect(c, 0.0f, 0.0f, len, 1.0f / Ui.scale(), color);
        m.pop();
    }

    private void drawBackground(DrawContext c, int mx, int my) {
        int accent = Config.accent();
        if (Config.guiBlur) {
            int top = Ui.alpha(0x04040A, 0.62f * openT);
            int bot = Ui.alpha(Ui.mix(0xFF04040A, accent, 0.32f), 0.55f * openT);
            c.fillGradient(0, 0, width, height, top, bot);
        } else {
            c.fill(0, 0, width, height, Ui.alpha(0x000000, 0.4f * openT));
        }

        if (!Config.guiParticles) return;
        float dt = Math.min(0.05f, Anim.dt());
        for (Dot d : dots) {
            d.x += d.vx * dt;
            d.y += d.vy * dt;
            // отталкивание от курсора
            float ddx = d.x - mx, ddy = d.y - my;
            float dist2 = ddx * ddx + ddy * ddy;
            if (dist2 < 3600.0f && dist2 > 0.01f) {
                float dist = (float) Math.sqrt(dist2);
                float push = (1.0f - dist / 60.0f) * 140.0f * dt;
                d.x += ddx / dist * push;
                d.y += ddy / dist * push;
            }
            if (d.x < -4) d.x = width + 4;
            if (d.x > width + 4) d.x = -4;
            if (d.y < -4) d.y = height + 4;
            if (d.y > height + 4) d.y = -4;
        }
        // линии между близкими точками (и к курсору)
        for (int i = 0; i < dots.size(); i++) {
            Dot a = dots.get(i);
            for (int j = i + 1; j < dots.size(); j++) {
                Dot b = dots.get(j);
                float dx = a.x - b.x, dy = a.y - b.y;
                float d2 = dx * dx + dy * dy;
                if (d2 < 3200.0f) {
                    float k = 1.0f - (float) Math.sqrt(d2) / 56.5f;
                    line(c, a.x, a.y, b.x, b.y, Ui.alpha(accent, 0.30f * k * openT));
                }
            }
            float mdx = a.x - mx, mdy = a.y - my;
            float m2 = mdx * mdx + mdy * mdy;
            if (m2 < 10000.0f) {
                float k = 1.0f - (float) Math.sqrt(m2) / 100.0f;
                line(c, a.x, a.y, mx, my, Ui.alpha(0xFFFFFF, 0.28f * k * openT));
            }
        }
        for (Dot d : dots) {
            Ui.rrectF(c, d.x - d.r * 2, d.y - d.r * 2, d.r * 4, d.r * 4, d.r * 2, Ui.alpha(accent, 0.10f * openT));
            Ui.rrectF(c, d.x - d.r, d.y - d.r, d.r * 2, d.r * 2, d.r, Ui.alpha(0xFFFFFF, 0.7f * openT));
        }
    }

    private void drawTrailAndRipples(DrawContext c, int mx, int my) {
        long now = System.currentTimeMillis();
        int accent = Config.accent();

        if (lastTx < 0 || Math.abs(mx - lastTx) + Math.abs(my - lastTy) > 1.5f) {
            trail[trailN % trail.length][0] = mx;
            trail[trailN % trail.length][1] = my;
            trail[trailN % trail.length][2] = now;
            trailN++;
            lastTx = mx;
            lastTy = my;
        }
        for (float[] t : trail) {
            float age = (now - t[2]) / 420.0f;
            if (t[2] == 0 || age >= 1.0f) continue;
            float r = 3.2f * (1.0f - age);
            Ui.rrectF(c, t[0] - r, t[1] - r, r * 2, r * 2, r, Ui.alpha(accent, 0.5f * (1.0f - age)));
        }

        if (Config.guiRipple) {
            for (int i = ripples.size() - 1; i >= 0; i--) {
                float[] rp = ripples.get(i);
                float age = (now - rp[2]) / 600.0f;
                if (age >= 1.0f) {
                    ripples.remove(i);
                    continue;
                }
                float e = Anim.ease(age);
                float r = 4.0f + e * 46.0f;
                // кольцо: внешний светлый круг и внутренний, который "прогрызает" центр
                Ui.rrectF(c, rp[0] - r, rp[1] - r, r * 2, r * 2, r, Ui.alpha(accent, 0.28f * (1.0f - age)));
                Ui.rrectF(c, rp[0] - r + 1.5f, rp[1] - r + 1.5f, r * 2 - 3, r * 2 - 3, r - 1.5f,
                        Ui.alpha(0x0A0A12, 0.30f * (1.0f - age)));
            }
        }
    }

    // ------------------------------------------------------------ рендер

    private Panel panelAt(double mx, double my) {
        for (int i = panels.size() - 1; i >= 0; i--) {
            Panel p = panels.get(i);
            if (Ui.in(mx, my, p.rx, p.ry, p.rw, p.rh)) return p;
        }
        return null;
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        Anim.frame();
        openT = Anim.step(openT, 1.0f, 12.0f);
        int accent = Config.accent();
        long now = System.currentTimeMillis();

        drawBackground(c, mouseX, mouseY);

        // заголовок с бегущим градиентом по буквам
        String title = "noomidls";
        int tw = Ui.width(textRenderer, title);
        float tx = (width - tw) / 2.0f;
        for (int i = 0; i < title.length(); i++) {
            String ch = String.valueOf(title.charAt(i));
            float wave = 0.5f + 0.5f * (float) Math.sin(now / 350.0 - i * 0.6);
            Ui.textF(c, textRenderer, ch, tx, 8 - (1.0f - openT) * 10, Ui.mix(0xFFFFFFFF, accent, wave));
            tx += Ui.width(textRenderer, title.substring(0, i + 1)) - Ui.width(textRenderer, title.substring(0, i));
        }

        hits.clear();
        Panel under = panelAt(mouseX, mouseY);

        for (Panel p : panels) {
            // волна появления: панели выезжают по очереди
            float local = MathHelper.clamp((now - openAt - p.idx * 55L) / 380.0f, 0.0f, 1.0f);
            float e = Config.uiAnim ? Anim.ease(local) : 1.0f;
            float oy = (1.0f - e) * -26.0f;

            p.col = Anim.step(p.col, p.collapsed ? 0.0f : 1.0f, 16.0f);

            int px = Math.round(p.x);
            int py = Math.round(p.y + oy);
            for (Row r : p.rows) if (r instanceof Toggle t) t.tickExpand();
            int bodyMax = Math.max(40, height - py - HEAD - 10);
            int content = p.contentHeight();
            int bodyFull = Math.min(content, bodyMax);
            int body = Math.round(bodyFull * p.col);

            int maxScroll = Math.max(0, content - bodyFull);
            p.scrollT = MathHelper.clamp(p.scrollT, 0, maxScroll);
            p.scroll = Anim.step(p.scroll, p.scrollT, 18.0f);

            int totalH = HEAD + body;
            p.rx = px;
            p.ry = py;
            p.rw = PW;
            p.rh = totalH;
            p.bodyTop = py + HEAD;
            p.bodyBottom = py + HEAD + body;

            boolean hoverPanel = under == p;
            int mx = hoverPanel && dragging == null ? mouseX : (dragging != null || movingPanel != null ? mouseX : -10000);
            int my = hoverPanel && dragging == null ? mouseY : (dragging != null || movingPanel != null ? mouseY : -10000);

            // свечение и тело
            if (Config.guiGlow) {
                for (int k = 4; k >= 1; k--) {
                    Ui.rrectF(c, px - k * 1.5f, py - k * 1.5f, PW + k * 3.0f, totalH + k * 3.0f, 9 + k * 1.5f,
                            Ui.alpha(accent, 0.045f * (e)));
                }
            }
            Ui.rrectF(c, px - 1, py - 1, PW + 2, totalH + 2, 10, BORDER);
            Ui.rrectF(c, px, py, PW, totalH, 9, BG);

            // заголовок
            Ui.rrectF(c, px, py, PW, HEAD, 9, HEAD_BG);
            if (body > 0) Ui.rect(c, px, py + HEAD - 9, px + PW, py + HEAD, HEAD_BG);
            // бегущая цветная линия под заголовком
            int segs = 24;
            float sw = PW / (float) segs;
            for (int i = 0; i < segs; i++) {
                float ph = 0.5f + 0.5f * (float) Math.sin(now / 600.0 + i * 0.35 + p.idx);
                Ui.rect(c, px + i * sw, py + HEAD - 2, px + (i + 1) * sw + 0.5f, py + HEAD,
                        Ui.mix(Ui.alpha(accent, 0.25f), accent, ph));
            }
            Ui.textMid(c, textRenderer, p.name, px + 10, py, HEAD - 2, TEXT);

            int on = 0, total = 0;
            for (Row r : p.rows) {
                if (r instanceof Toggle t) {
                    total++;
                    if (t.get.getAsBoolean()) on++;
                }
            }
            String cnt = on + "/" + total;
            Ui.textMid(c, textRenderer, cnt, px + PW - 10 - Ui.width(textRenderer, cnt), py, HEAD - 2,
                    on > 0 ? accent : MUTED);

            Hit hh = new Hit();
            hh.panel = p;
            hh.header = true;
            hh.x = px;
            hh.y = py;
            hh.w = PW;
            hits.add(hh);

            // содержимое с обрезкой по высоте панели
            if (body > 2) {
                c.enableScissor(px, p.bodyTop, px + PW, p.bodyBottom);
                int y = p.bodyTop + 4 - Math.round(p.scroll);
                for (Row r : p.rows) {
                    int rowH = r.height();
                    if (y + rowH > p.bodyTop - 2 && y < p.bodyBottom + 2) {
                        boolean visibleHover = my >= p.bodyTop && my < p.bodyBottom;
                        int hx = visibleHover ? mx : -10000;
                        int hy = visibleHover ? my : -10000;
                        r.render(c, px + 6, y, PW - 12, hx, hy);
                        addHit(p, r, null, px + 6, y, PW - 12);

                        if (r instanceof Toggle t && t.settings != null && t.ex > 0.01f) {
                            int sy = y + STRIDE;
                            int inner = Math.round((t.settingsHeight() + 4) * t.ex);
                            c.enableScissor(px, Math.max(p.bodyTop, sy - 2), px + PW, Math.min(p.bodyBottom, sy + inner));
                            Ui.rrectF(c, px + 8, sy - 3, PW - 16, t.settingsHeight() + 6, 6, Ui.alpha(0x000000, 0.28f));
                            int yy = sy + 1;
                            for (Row s : t.settings) {
                                if (yy + RH > p.bodyTop - 2 && yy < p.bodyBottom + 2) {
                                    s.render(c, px + 12, yy, PW - 24, hx, hy);
                                    if (t.ex > 0.92f) addHit(p, s, t, px + 12, yy, PW - 24);
                                }
                                yy += s.height();
                            }
                            c.disableScissor();
                        }
                    }
                    y += rowH;
                }
                c.disableScissor();

                // индикатор прокрутки
                if (maxScroll > 0) {
                    float th = Math.max(14.0f, bodyFull * (bodyFull / (float) content));
                    float ty = p.bodyTop + 2 + (bodyFull - 4 - th) * (p.scroll / maxScroll);
                    Ui.rrectF(c, px + PW - 3.5f, ty, 2, th, 1, Ui.alpha(accent, 0.7f));
                }
            }
        }

        drawTrailAndRipples(c, mouseX, mouseY);

        String hint = "ЛКМ - вкл/выкл   ПКМ - настройки   Колесо - прокрутка   RShift - закрыть";
        int hw = Ui.width(textRenderer, hint);
        Ui.textF(c, textRenderer, hint, (width - hw) / 2.0f, height - 12 + (1.0f - openT) * 14, Ui.alpha(0xFFFFFF, 0.45f * openT));
    }

    private void addHit(Panel p, Row r, Toggle parent, int x, int y, int w) {
        Hit h = new Hit();
        h.row = r;
        h.panel = p;
        h.parent = parent;
        h.x = x;
        h.y = y;
        h.w = w;
        hits.add(h);
    }

    // ------------------------------------------------------------ ввод

    private Hit hitAt(double mx, double my) {
        Panel top = panelAt(mx, my);
        if (top == null) return null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.panel != top) continue;
            if (h.header) {
                if (Ui.in(mx, my, h.x, h.y, h.w, HEAD)) return h;
                continue;
            }
            if (my < top.bodyTop || my >= top.bodyBottom) continue;
            if (Ui.in(mx, my, h.x, h.y, h.w, RH)) return h;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (listening != null) {
            listening.set.accept(-100 - button);
            listening = null;
            return true;
        }

        if (Config.guiRipple) {
            ripples.add(new float[]{(float) mouseX, (float) mouseY, System.currentTimeMillis()});
        }

        Panel top = panelAt(mouseX, mouseY);
        if (top == null) return super.mouseClicked(mouseX, mouseY, button);

        // панель, по которой кликнули, поднимается наверх
        panels.remove(top);
        panels.add(top);

        Hit h = hitAt(mouseX, mouseY);
        if (h == null) return true;

        if (h.header) {
            if (button == 0) {
                movingPanel = top;
                moveOffX = (float) mouseX - top.x;
                moveOffY = (float) mouseY - top.y;
            } else if (button == 1) {
                top.collapsed = !top.collapsed;
                saveLayout();
            }
            return true;
        }

        if (button == 1 && h.row instanceof Toggle t && t.settings != null && h.parent == null) {
            t.expanded = !t.expanded;
            return true;
        }
        if (button == 0 && h.row.click(h.x, h.y, h.w, mouseX, mouseY)) {
            dragging = h.row;
            return true;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging != null) {
            dragging.drag(mouseX);
            return true;
        }
        if (movingPanel != null) {
            movingPanel.x = (float) mouseX - moveOffX;
            movingPanel.y = (float) mouseY - moveOffY;
            clamp();
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        if (movingPanel != null) saveLayout();
        movingPanel = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        Panel p = panelAt(mouseX, mouseY);
        if (p != null) {
            p.scrollT -= (float) verticalAmount * 24.0f;
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            listening.set.accept(keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode);
            listening = null;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        saveLayout();
        Config.save();
        super.removed();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
